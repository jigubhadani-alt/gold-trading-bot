package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.model.AccountSummary
import com.example.data.model.AppLanguage
import com.example.data.model.AppStrings
import com.example.data.model.BacktestResult
import com.example.data.model.BacktestScenario
import com.example.data.model.BotLog
import com.example.data.model.BotStrategyConfig
import com.example.data.model.CandleStick
import com.example.data.model.LogLevel
import com.example.data.model.MarketTick
import com.example.data.model.PivotLevels
import com.example.data.model.SignalDecision
import com.example.data.model.StrategyType
import com.example.data.model.Timeframe
import com.example.data.model.Trade
import com.example.data.model.TradeStatus
import com.example.data.model.TradeType
import com.example.data.repository.TradingRepository
import com.example.engine.BacktestEngine
import com.example.engine.GoldMarketEngine
import com.example.engine.GoldTradingBotEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.max

class TradingViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    val repository = TradingRepository(db)

    val marketEngine = GoldMarketEngine()
    val botEngine = GoldTradingBotEngine(repository)
    val backtestEngine = BacktestEngine()

    // Language state
    private val _language = MutableStateFlow(AppLanguage.ENGLISH)
    val language: StateFlow<AppLanguage> = _language.asStateFlow()

    // Base capital
    private val _baseCapital = MutableStateFlow(10000.0)
    val baseCapital: StateFlow<Double> = _baseCapital.asStateFlow()

    // Backtest results
    private val _backtestResult = MutableStateFlow<BacktestResult?>(null)
    val backtestResult: StateFlow<BacktestResult?> = _backtestResult.asStateFlow()

    private val _isBacktesting = MutableStateFlow(false)
    val isBacktesting: StateFlow<Boolean> = _isBacktesting.asStateFlow()

    // Settings
    private val _riskPercent = MutableStateFlow(2.0)
    val riskPercent: StateFlow<Double> = _riskPercent.asStateFlow()

    private val _maxDailyLoss = MutableStateFlow(500.0)
    val maxDailyLoss: StateFlow<Double> = _maxDailyLoss.asStateFlow()

    // Observables
    val currentTick: StateFlow<MarketTick> = marketEngine.currentTick
    val activeCandles: StateFlow<List<CandleStick>> = marketEngine.activeCandles
    val selectedTimeframe: StateFlow<Timeframe> = marketEngine.selectedTimeframe
    val pivotLevels: StateFlow<PivotLevels> = marketEngine.pivotLevels
    val latestSignal: StateFlow<SignalDecision> = marketEngine.latestSignal

    val isBotActive: StateFlow<Boolean> = botEngine.isBotActive
    val strategies: StateFlow<List<BotStrategyConfig>> = botEngine.strategies
    val simulationSpeed: StateFlow<Int> = botEngine.simulationSpeed

    val recentLogs: StateFlow<List<BotLog>> = repository.recentLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Convert raw entities to domain Trades with live price calculation
    val openTrades: StateFlow<List<Trade>> = combine(
        repository.openTrades,
        currentTick
    ) { entities, tick ->
        entities.map { it.toDomain(tick.price) }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val closedTrades: StateFlow<List<Trade>> = repository.closedTrades
        .combine(currentTick) { entities, tick ->
            entities.map { it.toDomain(tick.price) }
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Account Summary
    val accountSummary: StateFlow<AccountSummary> = combine(
        openTrades,
        closedTrades,
        _baseCapital
    ) { open, closed, base ->
        val floatingPnl = open.sumOf { it.pnl }
        val realizedPnl = closed.sumOf { it.pnl }
        val balance = Math.round((base + realizedPnl) * 100.0) / 100.0
        val equity = Math.round((balance + floatingPnl) * 100.0) / 100.0
        
        // 1 lot margin for Gold = $1000 margin
        val marginUsed = open.sumOf { it.lotSize * 1000.0 }
        val freeMargin = max(0.0, equity - marginUsed)
        val marginLevel = if (marginUsed > 0) (equity / marginUsed) * 100.0 else 0.0

        val totalTrades = closed.size
        val winTrades = closed.count { it.pnl > 0 }
        val lossTrades = closed.count { it.pnl < 0 }

        val grossProfit = closed.filter { it.pnl > 0 }.sumOf { it.pnl }
        val grossLoss = Math.abs(closed.filter { it.pnl < 0 }.sumOf { it.pnl })
        val profitFactor = if (grossLoss == 0.0) grossProfit else grossProfit / grossLoss

        val bestTrade = closed.maxOfOrNull { it.pnl } ?: 0.0
        val worstTrade = closed.minOfOrNull { it.pnl } ?: 0.0

        AccountSummary(
            balance = balance,
            equity = equity,
            marginUsed = Math.round(marginUsed * 100.0) / 100.0,
            freeMargin = Math.round(freeMargin * 100.0) / 100.0,
            marginLevelPercent = Math.round(marginLevel * 10.0) / 10.0,
            floatingPnl = Math.round(floatingPnl * 100.0) / 100.0,
            totalRealizedProfit = Math.round(realizedPnl * 100.0) / 100.0,
            totalTrades = totalTrades,
            winningTrades = winTrades,
            losingTrades = lossTrades,
            profitFactor = Math.round(profitFactor * 100.0) / 100.0,
            bestTrade = Math.round(bestTrade * 100.0) / 100.0,
            worstTrade = Math.round(worstTrade * 100.0) / 100.0
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AccountSummary())

    private var simulationLoopJob: Job? = null

    init {
        startSimulationLoop()
        runDefaultBacktest()
    }

    private fun startSimulationLoop() {
        simulationLoopJob?.cancel()
        simulationLoopJob = viewModelScope.launch {
            while (isActive) {
                val tick = marketEngine.tick()
                val candles = activeCandles.value
                val signal = latestSignal.value
                val currentOpen = openTrades.value

                botEngine.onTick(tick, candles, signal, currentOpen)

                val speed = botEngine.simulationSpeed.value
                val delayMs = (1000L / speed).coerceAtLeast(100L)
                delay(delayMs)
            }
        }
    }

    fun setLanguage(lang: AppLanguage) {
        _language.value = lang
    }

    fun toggleLanguage() {
        _language.value = if (_language.value == AppLanguage.ENGLISH) AppLanguage.GUJARATI else AppLanguage.ENGLISH
    }

    fun getString(key: String): String {
        return AppStrings.get(key, _language.value)
    }

    fun toggleBot() {
        val newState = !isBotActive.value
        botEngine.setBotActive(newState)
        viewModelScope.launch {
            val statusMsg = if (newState) "🤖 Automated Gold Bot ACTIVATED" else "⏸️ Automated Gold Bot PAUSED"
            repository.logBotActivity(
                BotLog(
                    message = statusMsg,
                    level = if (newState) LogLevel.SUCCESS else LogLevel.INFO
                )
            )
        }
    }

    fun setSimulationSpeed(speed: Int) {
        botEngine.setSimulationSpeed(speed)
    }

    fun setTimeframe(tf: Timeframe) {
        marketEngine.setTimeframe(tf)
    }

    fun toggleStrategy(type: StrategyType) {
        botEngine.toggleStrategy(type)
    }

    fun updateRiskPercent(percent: Double) {
        _riskPercent.value = percent
    }

    fun updateMaxDailyLoss(loss: Double) {
        _maxDailyLoss.value = loss
    }

    fun openManualTrade(type: TradeType, lotSize: Double, slPips: Double, tpPips: Double) {
        viewModelScope.launch {
            val tick = currentTick.value
            val entryPrice = if (type == TradeType.BUY) tick.ask else tick.bid
            val slDist = slPips / 10.0
            val tpDist = tpPips / 10.0

            val stopLoss = if (type == TradeType.BUY) {
                Math.round((entryPrice - slDist) * 100.0) / 100.0
            } else {
                Math.round((entryPrice + slDist) * 100.0) / 100.0
            }

            val takeProfit = if (type == TradeType.BUY) {
                Math.round((entryPrice + tpDist) * 100.0) / 100.0
            } else {
                Math.round((entryPrice - tpDist) * 100.0) / 100.0
            }

            val ticket = "MN-${(1000..9999).random()}"

            val trade = Trade(
                ticketNumber = ticket,
                type = type,
                symbol = "XAU/USD",
                lotSize = lotSize,
                entryPrice = entryPrice,
                currentPrice = entryPrice,
                stopLoss = stopLoss,
                takeProfit = takeProfit,
                status = TradeStatus.OPEN,
                strategy = StrategyType.MANUAL,
                isTrailingEnabled = true,
                highestPriceReached = entryPrice,
                lowestPriceReached = entryPrice
            )

            repository.openTrade(trade)

            repository.logBotActivity(
                BotLog(
                    message = "👤 [MANUAL TRADE] #$ticket ${type.name} $lotSize Lots @ $${entryPrice} (SL: $${stopLoss}, TP: $${takeProfit})",
                    level = LogLevel.TRADE,
                    strategy = StrategyType.MANUAL
                )
            )
        }
    }

    fun closeTrade(trade: Trade) {
        viewModelScope.launch {
            val tick = currentTick.value
            val currentPrice = if (trade.type == TradeType.BUY) tick.bid else tick.ask
            val pips = if (trade.type == TradeType.BUY) (currentPrice - trade.entryPrice) * 10.0 else (trade.entryPrice - currentPrice) * 10.0
            val pnl = (pips / 10.0) * 100.0 * trade.lotSize

            repository.closeTrade(
                id = trade.id,
                exitPrice = currentPrice,
                pnl = Math.round(pnl * 100.0) / 100.0,
                pips = Math.round(pips * 10.0) / 10.0,
                reason = "Manual Close ($${Math.round(pnl)})"
            )

            repository.logBotActivity(
                BotLog(
                    message = "🚪 [CLOSED] #${trade.ticketNumber} ${trade.type} at $${currentPrice} (P&L: $${Math.round(pnl)})",
                    level = if (pnl >= 0) LogLevel.SUCCESS else LogLevel.INFO,
                    strategy = trade.strategy
                )
            )
        }
    }

    fun closeAllTrades() {
        viewModelScope.launch {
            val open = openTrades.value
            for (t in open) {
                closeTrade(t)
            }
        }
    }

    fun clearLogs() {
        viewModelScope.launch {
            repository.clearLogs()
        }
    }

    fun runBacktest(
        scenario: BacktestScenario,
        strategy: StrategyType,
        capital: Double = 10000.0,
        lotSize: Double = 0.50,
        sl: Double = 25.0,
        tp: Double = 50.0
    ) {
        viewModelScope.launch {
            _isBacktesting.value = true
            delay(500) // visual feedback
            val result = backtestEngine.runBacktest(
                scenario = scenario,
                strategy = strategy,
                initialBalance = capital,
                lotSize = lotSize,
                slPips = sl,
                tpPips = tp
            )
            _backtestResult.value = result
            _isBacktesting.value = false
        }
    }

    private fun runDefaultBacktest() {
        viewModelScope.launch {
            val res = backtestEngine.runBacktest(
                scenario = BacktestScenario.BULL_RALLY,
                strategy = StrategyType.TREND_FOLLOWING
            )
            _backtestResult.value = res
        }
    }

    fun resetAccount(newBalance: Double = 10000.0) {
        viewModelScope.launch {
            _baseCapital.value = newBalance
            repository.resetAllTrades()
            repository.logBotActivity(
                BotLog(
                    message = "🔄 Account reset to $$newBalance capital",
                    level = LogLevel.INFO
                )
            )
        }
    }
}
