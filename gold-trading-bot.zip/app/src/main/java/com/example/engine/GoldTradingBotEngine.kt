package com.example.engine

import com.example.data.model.BotLog
import com.example.data.model.BotStrategyConfig
import com.example.data.model.CandleStick
import com.example.data.model.LogLevel
import com.example.data.model.MarketTick
import com.example.data.model.SignalDecision
import com.example.data.model.SignalType
import com.example.data.model.StrategyType
import com.example.data.model.Trade
import com.example.data.model.TradeStatus
import com.example.data.model.TradeType
import com.example.data.repository.TradingRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID
import kotlin.math.max
import kotlin.math.min

class GoldTradingBotEngine(
    private val repository: TradingRepository
) {
    private val _isBotActive = MutableStateFlow(true)
    val isBotActive: StateFlow<Boolean> = _isBotActive.asStateFlow()

    private val _strategies = MutableStateFlow(
        listOf(
            BotStrategyConfig(
                type = StrategyType.SCALPER,
                isEnabled = true,
                defaultLotSize = 0.50,
                stopLossPips = 25.0,
                takeProfitPips = 50.0,
                trailingStopEnabled = true,
                winCount = 14,
                lossCount = 4,
                totalProfit = 1420.50
            ),
            BotStrategyConfig(
                type = StrategyType.TREND_FOLLOWING,
                isEnabled = true,
                defaultLotSize = 0.75,
                stopLossPips = 40.0,
                takeProfitPips = 90.0,
                trailingStopEnabled = true,
                winCount = 9,
                lossCount = 3,
                totalProfit = 2850.00
            ),
            BotStrategyConfig(
                type = StrategyType.GRID_BOT,
                isEnabled = false,
                defaultLotSize = 0.25,
                stopLossPips = 60.0,
                takeProfitPips = 30.0,
                trailingStopEnabled = false,
                winCount = 22,
                lossCount = 7,
                totalProfit = 980.20
            ),
            BotStrategyConfig(
                type = StrategyType.BREAKOUT,
                isEnabled = true,
                defaultLotSize = 0.50,
                stopLossPips = 30.0,
                takeProfitPips = 75.0,
                trailingStopEnabled = true,
                winCount = 8,
                lossCount = 2,
                totalProfit = 1890.00
            )
        )
    )
    val strategies: StateFlow<List<BotStrategyConfig>> = _strategies.asStateFlow()

    private val _simulationSpeed = MutableStateFlow(1) // 1x, 2x, 5x, 10x
    val simulationSpeed: StateFlow<Int> = _simulationSpeed.asStateFlow()

    private val _maxOpenTrades = MutableStateFlow(5)
    val maxOpenTrades: StateFlow<Int> = _maxOpenTrades.asStateFlow()

    private var lastTradeTriggerTime = 0L
    private val minCooldownBetweenBotTrades = 4500L // cooldown in ms

    fun setBotActive(active: Boolean) {
        _isBotActive.value = active
    }

    fun setSimulationSpeed(speed: Int) {
        _simulationSpeed.value = speed
    }

    fun setMaxOpenTrades(max: Int) {
        _maxOpenTrades.value = max
    }

    fun toggleStrategy(type: StrategyType) {
        _strategies.value = _strategies.value.map {
            if (it.type == type) it.copy(isEnabled = !it.isEnabled) else it
        }
    }

    fun updateStrategyConfig(config: BotStrategyConfig) {
        _strategies.value = _strategies.value.map {
            if (it.type == config.type) config else it
        }
    }

    suspend fun onTick(
        tick: MarketTick,
        activeCandles: List<CandleStick>,
        signal: SignalDecision,
        currentOpenTrades: List<Trade>
    ) {
        // 1. Manage Active Positions (Check SL, TP, Trailing Stop)
        manageOpenPositions(tick, currentOpenTrades)

        // 2. Check if Auto Bot is enabled and can trade
        if (!_isBotActive.value) return
        if (currentOpenTrades.size >= _maxOpenTrades.value) return

        val now = System.currentTimeMillis()
        if (now - lastTradeTriggerTime < (minCooldownBetweenBotTrades / _simulationSpeed.value)) return

        // 3. Scan strategies
        evaluateStrategies(tick, activeCandles, signal, currentOpenTrades)
    }

    private suspend fun manageOpenPositions(tick: MarketTick, openTrades: List<Trade>) {
        for (trade in openTrades) {
            val isBuy = trade.type == TradeType.BUY
            val currentPrice = if (isBuy) tick.bid else tick.ask

            // Update highest/lowest reached price for trailing stop
            val newHigh = max(trade.highestPriceReached, currentPrice)
            val newLow = min(trade.lowestPriceReached, currentPrice)

            var updatedStopLoss = trade.stopLoss

            // Trailing Stop Loss logic
            if (trade.isTrailingEnabled) {
                if (isBuy) {
                    val profitPips = (currentPrice - trade.entryPrice) * 10.0
                    // If profit > 20 pips, trail stop-loss 15 pips behind peak
                    if (profitPips >= 20.0) {
                        val trailingLevel = Math.round((newHigh - 1.50) * 100.0) / 100.0
                        if (trailingLevel > updatedStopLoss) {
                            updatedStopLoss = trailingLevel
                        }
                    }
                } else {
                    val profitPips = (trade.entryPrice - currentPrice) * 10.0
                    if (profitPips >= 20.0) {
                        val trailingLevel = Math.round((newLow + 1.50) * 100.0) / 100.0
                        if (trailingLevel < updatedStopLoss) {
                            updatedStopLoss = trailingLevel
                        }
                    }
                }
            }

            // Check TP Hit
            val isTpHit = if (isBuy) currentPrice >= trade.takeProfit else currentPrice <= trade.takeProfit
            // Check SL Hit
            val isSlHit = if (isBuy) currentPrice <= updatedStopLoss else currentPrice >= updatedStopLoss

            if (isTpHit) {
                val pips = if (isBuy) (trade.takeProfit - trade.entryPrice) * 10.0 else (trade.entryPrice - trade.takeProfit) * 10.0
                val pnl = (pips / 10.0) * 100.0 * trade.lotSize
                repository.closeTrade(
                    id = trade.id,
                    exitPrice = trade.takeProfit,
                    pnl = Math.round(pnl * 100.0) / 100.0,
                    pips = Math.round(pips * 10.0) / 10.0,
                    reason = "Take Profit Hit (🎯 +$${Math.round(pnl)})"
                )
                repository.logBotActivity(
                    BotLog(
                        message = "🎯 [TP HIT] #${trade.ticketNumber} ${trade.type} Closed at $${trade.takeProfit} (+$${Math.round(pnl)})",
                        level = LogLevel.SUCCESS,
                        strategy = trade.strategy
                    )
                )
                recordStrategyResult(trade.strategy, isWin = true, profit = pnl)
            } else if (isSlHit) {
                val pips = if (isBuy) (updatedStopLoss - trade.entryPrice) * 10.0 else (trade.entryPrice - updatedStopLoss) * 10.0
                val pnl = (pips / 10.0) * 100.0 * trade.lotSize
                val reason = if (pnl >= 0) "Trailing Stop Hit (🔒 +$${Math.round(pnl)})" else "Stop Loss Hit (🛑 -$${Math.round(-pnl)})"
                repository.closeTrade(
                    id = trade.id,
                    exitPrice = updatedStopLoss,
                    pnl = Math.round(pnl * 100.0) / 100.0,
                    pips = Math.round(pips * 10.0) / 10.0,
                    reason = reason
                )
                repository.logBotActivity(
                    BotLog(
                        message = "🛑 [SL HIT] #${trade.ticketNumber} ${trade.type} Closed at $${updatedStopLoss} ($${Math.round(pnl)})",
                        level = if (pnl >= 0) LogLevel.SUCCESS else LogLevel.WARNING,
                        strategy = trade.strategy
                    )
                )
                recordStrategyResult(trade.strategy, isWin = pnl >= 0, profit = pnl)
            } else {
                // Update live trade in memory/DB if trailing SL moved
                if (updatedStopLoss != trade.stopLoss || newHigh != trade.highestPriceReached || newLow != trade.lowestPriceReached) {
                    repository.updateTrade(
                        trade.copy(
                            stopLoss = updatedStopLoss,
                            highestPriceReached = newHigh,
                            lowestPriceReached = newLow
                        )
                    )
                }
            }
        }
    }

    private suspend fun evaluateStrategies(
        tick: MarketTick,
        candles: List<CandleStick>,
        signal: SignalDecision,
        openTrades: List<Trade>
    ) {
        if (candles.size < 20) return

        val last = candles.last()
        val prev = candles[candles.size - 2]
        val activeStrats = _strategies.value.filter { it.isEnabled }

        for (strat in activeStrats) {
            val existingForStrat = openTrades.count { it.strategy == strat.type }
            if (existingForStrat >= 2) continue // max 2 per specific strategy

            var triggerTrade: TradeType? = null
            var triggerReason = ""

            when (strat.type) {
                StrategyType.SCALPER -> {
                    // Scalper triggers on extreme RSI + Bollinger Band rejection
                    val rsi = last.rsi14 ?: 50.0
                    val lowerBand = last.lowerBand ?: tick.price
                    val upperBand = last.upperBand ?: tick.price

                    if (rsi < 30.0 && tick.price <= (lowerBand + 0.50)) {
                        triggerTrade = TradeType.BUY
                        triggerReason = "RSI Oversold ($rsi) + Lower BB Touch"
                    } else if (rsi > 70.0 && tick.price >= (upperBand - 0.50)) {
                        triggerTrade = TradeType.SELL
                        triggerReason = "RSI Overbought ($rsi) + Upper BB Touch"
                    }
                }

                StrategyType.TREND_FOLLOWING -> {
                    // Golden Trend: EMA 9 crosses above EMA 21 while above EMA 50
                    val ema9 = last.ema9 ?: tick.price
                    val ema21 = last.ema21 ?: tick.price
                    val ema50 = last.ema50 ?: tick.price
                    val prevEma9 = prev.ema9 ?: tick.price
                    val prevEma21 = prev.ema21 ?: tick.price

                    if (prevEma9 <= prevEma21 && ema9 > ema21 && ema21 > ema50) {
                        triggerTrade = TradeType.BUY
                        triggerReason = "EMA 9/21 Golden Bull Cross above EMA 50"
                    } else if (prevEma9 >= prevEma21 && ema9 < ema21 && ema21 < ema50) {
                        triggerTrade = TradeType.SELL
                        triggerReason = "EMA 9/21 Death Cross below EMA 50"
                    }
                }

                StrategyType.GRID_BOT -> {
                    // Grid Accumulator: Buys at lower price steps and Sells at higher steps
                    val basePrice = 2745.0
                    val stepSize = 4.0
                    val offset = (tick.price - basePrice) % stepSize
                    if (offset < 0.30 && signal.type != SignalType.STRONG_SELL) {
                        triggerTrade = TradeType.BUY
                        triggerReason = "Grid Level Buy Step at $${tick.price}"
                    } else if (offset > (stepSize - 0.30) && signal.type != SignalType.STRONG_BUY) {
                        triggerTrade = TradeType.SELL
                        triggerReason = "Grid Level Sell Step at $${tick.price}"
                    }
                }

                StrategyType.BREAKOUT -> {
                    // Breakout Hunter: High volume + Strong Signal
                    if (signal.type == SignalType.STRONG_BUY && signal.confidence >= 75) {
                        triggerTrade = TradeType.BUY
                        triggerReason = "Momentum Breakout Surge (Confidence ${signal.confidence}%)"
                    } else if (signal.type == SignalType.STRONG_SELL && signal.confidence >= 75) {
                        triggerTrade = TradeType.SELL
                        triggerReason = "Downside Liquidity Breakdown (Confidence ${signal.confidence}%)"
                    }
                }

                StrategyType.MANUAL -> {}
            }

            if (triggerTrade != null) {
                executeBotTrade(strat, triggerTrade, tick, triggerReason)
                lastTradeTriggerTime = System.currentTimeMillis()
                break // execute 1 trade per cycle
            }
        }
    }

    private suspend fun executeBotTrade(
        strat: BotStrategyConfig,
        type: TradeType,
        tick: MarketTick,
        reason: String
    ) {
        val entryPrice = if (type == TradeType.BUY) tick.ask else tick.bid
        val slDist = strat.stopLossPips / 10.0
        val tpDist = strat.takeProfitPips / 10.0

        val stopLoss = if (type == TradeType.BUY) {
            Math.round((entryPrice - slDist) * 100.0) / 100.0
        } else {
            Math.round((entryPrice + slDist) * 100.0) / 100.0
        }

        val takeProfit = if (type == TradeType.BUY) {
            Math.round((entryPrice + tpDist) * 100.0) / 100.0
        } else {
            Math.round((entryPrice - tpDist) * 100.0) / 100.0
        }

        val ticket = "GB-${(1000..9999).random()}"

        val trade = Trade(
            ticketNumber = ticket,
            type = type,
            symbol = "XAU/USD",
            lotSize = strat.defaultLotSize,
            entryPrice = entryPrice,
            currentPrice = entryPrice,
            stopLoss = stopLoss,
            takeProfit = takeProfit,
            status = TradeStatus.OPEN,
            strategy = strat.type,
            isTrailingEnabled = strat.trailingStopEnabled,
            highestPriceReached = entryPrice,
            lowestPriceReached = entryPrice
        )

        repository.openTrade(trade)

        repository.logBotActivity(
            BotLog(
                message = "⚡ [BOT ENTRY] #$ticket ${type.name} ${strat.defaultLotSize} Lots @ $${entryPrice} | $reason",
                level = LogLevel.TRADE,
                strategy = strat.type
            )
        )
    }

    private fun recordStrategyResult(type: StrategyType, isWin: Boolean, profit: Double) {
        _strategies.value = _strategies.value.map {
            if (it.type == type) {
                it.copy(
                    winCount = if (isWin) it.winCount + 1 else it.winCount,
                    lossCount = if (!isWin) it.lossCount + 1 else it.lossCount,
                    totalProfit = Math.round((it.totalProfit + profit) * 100.0) / 100.0
                )
            } else {
                it
            }
        }
    }
}
