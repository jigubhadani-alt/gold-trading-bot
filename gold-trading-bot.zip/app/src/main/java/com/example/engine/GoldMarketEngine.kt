package com.example.engine

import com.example.data.model.CandleStick
import com.example.data.model.MarketTick
import com.example.data.model.PivotLevels
import com.example.data.model.SignalDecision
import com.example.data.model.SignalType
import com.example.data.model.Timeframe
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt
import kotlin.random.Random

class GoldMarketEngine {

    private var currentPrice: Double = 2748.50
    private var high24h: Double = 2762.30
    private var low24h: Double = 2731.80
    private var volume24h: Double = 148520.0
    private var startOfDayPrice: Double = 2736.00

    private val _currentTick = MutableStateFlow(
        MarketTick(
            price = currentPrice,
            bid = currentPrice - 0.15,
            ask = currentPrice + 0.15,
            spread = 0.30,
            change24h = currentPrice - startOfDayPrice,
            changePercent24h = ((currentPrice - startOfDayPrice) / startOfDayPrice) * 100.0,
            high24h = high24h,
            low24h = low24h,
            volume24h = volume24h
        )
    )
    val currentTick: StateFlow<MarketTick> = _currentTick.asStateFlow()

    // Stores candles per timeframe
    private val candleMap = mutableMapOf<Timeframe, MutableList<CandleStick>>()

    private val _activeCandles = MutableStateFlow<List<CandleStick>>(emptyList())
    val activeCandles: StateFlow<List<CandleStick>> = _activeCandles.asStateFlow()

    private val _selectedTimeframe = MutableStateFlow(Timeframe.M1)
    val selectedTimeframe: StateFlow<Timeframe> = _selectedTimeframe.asStateFlow()

    private val _pivotLevels = MutableStateFlow(calculatePivots(high24h, low24h, currentPrice))
    val pivotLevels: StateFlow<PivotLevels> = _pivotLevels.asStateFlow()

    private val _latestSignal = MutableStateFlow(
        SignalDecision(
            type = SignalType.NEUTRAL,
            score = 0,
            confidence = 50,
            reason = "Scanning market indicators...",
            suggestedSl = currentPrice - 3.5,
            suggestedTp = currentPrice + 7.0
        )
    )
    val latestSignal: StateFlow<SignalDecision> = _latestSignal.asStateFlow()

    // Micro-simulation parameters
    private var trendBias: Double = 0.05 // slightly bullish gold trend
    private var volatility: Double = 0.45

    init {
        // Initialize synthetic historical candles for all timeframes
        initHistoricalCandles()
        updateActiveCandles()
    }

    fun setTimeframe(tf: Timeframe) {
        _selectedTimeframe.value = tf
        updateActiveCandles()
    }

    private fun initHistoricalCandles() {
        val now = System.currentTimeMillis()
        var seedPrice = 2725.0

        for (tf in Timeframe.values()) {
            val list = mutableListOf<CandleStick>()
            val candleCount = 80
            val tfMillis = tf.seconds * 1000L
            var t = now - (candleCount * tfMillis)

            for (i in 0 until candleCount) {
                val step = (Random.nextDouble(-1.0, 1.0) * volatility * sqrt(tf.seconds.toDouble() / 60.0)) + (trendBias * 0.1)
                val open = seedPrice
                val close = open + step
                val high = max(open, close) + Random.nextDouble(0.1, 0.9 * volatility)
                val low = min(open, close) - Random.nextDouble(0.1, 0.9 * volatility)
                val vol = Random.nextDouble(100.0, 1200.0)

                list.add(
                    CandleStick(
                        timestamp = t,
                        open = Math.round(open * 100.0) / 100.0,
                        high = Math.round(high * 100.0) / 100.0,
                        low = Math.round(low * 100.0) / 100.0,
                        close = Math.round(close * 100.0) / 100.0,
                        volume = Math.round(vol * 10.0) / 10.0
                    )
                )

                seedPrice = close
                t += tfMillis
            }

            // Calculate indicators for historical series
            candleMap[tf] = computeIndicators(list).toMutableList()
        }

        currentPrice = seedPrice
    }

    fun tick(): MarketTick {
        // Stochastic Brownian walk with occasional momentum bursts
        val randomWalk = (Random.nextDouble(-1.0, 1.0) * volatility * 0.4)
        val biasFactor = trendBias * 0.05
        val spike = if (Random.nextInt(100) < 4) Random.nextDouble(-1.8, 2.2) else 0.0 // sudden news spike

        val delta = randomWalk + biasFactor + spike
        currentPrice = Math.round((currentPrice + delta) * 100.0) / 100.0
        if (currentPrice < 1500.0) currentPrice = 1500.0

        if (currentPrice > high24h) high24h = currentPrice
        if (currentPrice < low24h) low24h = currentPrice
        volume24h += Random.nextDouble(5.0, 35.0)

        val spread = 0.20 + (Random.nextDouble(0.0, 0.15))
        val bid = Math.round((currentPrice - (spread / 2.0)) * 100.0) / 100.0
        val ask = Math.round((currentPrice + (spread / 2.0)) * 100.0) / 100.0

        val tick = MarketTick(
            symbol = "XAU/USD",
            price = currentPrice,
            bid = bid,
            ask = ask,
            spread = Math.round(spread * 100.0) / 100.0,
            change24h = Math.round((currentPrice - startOfDayPrice) * 100.0) / 100.0,
            changePercent24h = Math.round((((currentPrice - startOfDayPrice) / startOfDayPrice) * 100.0) * 100.0) / 100.0,
            high24h = high24h,
            low24h = low24h,
            volume24h = Math.round(volume24h * 10.0) / 10.0,
            timestamp = System.currentTimeMillis()
        )
        _currentTick.value = tick

        // Update real-time candles across timeframes
        updateCandlesWithTick(currentPrice)
        updateActiveCandles()

        // Calculate real-time signal
        evaluateAiSignal()

        return tick
    }

    private fun updateCandlesWithTick(price: Double) {
        val now = System.currentTimeMillis()
        for (tf in Timeframe.values()) {
            val list = candleMap[tf] ?: mutableListOf()
            val tfMillis = tf.seconds * 1000L

            if (list.isEmpty()) {
                list.add(CandleStick(now, price, price, price, price, 10.0))
            } else {
                val lastCandle = list.last()
                val isNewPeriod = (now - lastCandle.timestamp) >= tfMillis

                if (isNewPeriod) {
                    val newCandle = CandleStick(
                        timestamp = lastCandle.timestamp + tfMillis,
                        open = lastCandle.close,
                        high = max(lastCandle.close, price),
                        low = min(lastCandle.close, price),
                        close = price,
                        volume = Random.nextDouble(10.0, 80.0)
                    )
                    list.add(newCandle)
                    if (list.size > 120) list.removeAt(0)
                } else {
                    val updated = lastCandle.copy(
                        high = max(lastCandle.high, price),
                        low = min(lastCandle.low, price),
                        close = price,
                        volume = lastCandle.volume + Random.nextDouble(0.5, 3.0)
                    )
                    list[list.size - 1] = updated
                }
            }

            candleMap[tf] = computeIndicators(list).toMutableList()
        }
    }

    private fun updateActiveCandles() {
        val list = candleMap[_selectedTimeframe.value] ?: emptyList()
        _activeCandles.value = list.takeLast(60)
        _pivotLevels.value = calculatePivots(high24h, low24h, currentPrice)
    }

    private fun computeIndicators(rawList: List<CandleStick>): List<CandleStick> {
        if (rawList.isEmpty()) return rawList
        val closes = rawList.map { it.close }

        // EMA 9, 21, 50
        val ema9 = calculateEMA(closes, 9)
        val ema21 = calculateEMA(closes, 21)
        val ema50 = calculateEMA(closes, 50)

        // RSI 14
        val rsi14 = calculateRSI(closes, 14)

        // Bollinger Bands 20, 2.0
        val (upperBB, midBB, lowerBB) = calculateBollingerBands(closes, 20, 2.0)

        // MACD (12, 26, 9)
        val ema12 = calculateEMA(closes, 12)
        val ema26 = calculateEMA(closes, 26)
        val macdLine = List(closes.size) { i -> ema12[i] - ema26[i] }
        val macdSignal = calculateEMA(macdLine, 9)
        val macdHist = List(closes.size) { i -> macdLine[i] - macdSignal[i] }

        return rawList.mapIndexed { i, candle ->
            candle.copy(
                ema9 = ema9.getOrNull(i),
                ema21 = ema21.getOrNull(i),
                ema50 = ema50.getOrNull(i),
                rsi14 = rsi14.getOrNull(i),
                upperBand = upperBB.getOrNull(i),
                middleBand = midBB.getOrNull(i),
                lowerBand = lowerBB.getOrNull(i),
                macd = macdLine.getOrNull(i),
                macdSignal = macdSignal.getOrNull(i),
                macdHist = macdHist.getOrNull(i)
            )
        }
    }

    private fun calculateEMA(values: List<Double>, period: Int): List<Double> {
        if (values.isEmpty()) return emptyList()
        val result = mutableListOf<Double>()
        val multiplier = 2.0 / (period + 1.0)

        var prevEMA = values.take(period).average()
        for (i in values.indices) {
            if (i < period - 1) {
                result.add(values[i])
            } else if (i == period - 1) {
                result.add(prevEMA)
            } else {
                val currentEMA = ((values[i] - prevEMA) * multiplier) + prevEMA
                result.add(currentEMA)
                prevEMA = currentEMA
            }
        }
        return result
    }

    private fun calculateRSI(closes: List<Double>, period: Int = 14): List<Double> {
        if (closes.size < period + 1) return List(closes.size) { 50.0 }
        val result = mutableListOf<Double>()

        var gainSum = 0.0
        var lossSum = 0.0

        for (i in 1..period) {
            val change = closes[i] - closes[i - 1]
            if (change >= 0) gainSum += change else lossSum += abs(change)
        }

        var avgGain = gainSum / period
        var avgLoss = lossSum / period

        // Fill initial
        for (i in 0 until period) {
            result.add(50.0)
        }

        var rs = if (avgLoss == 0.0) 100.0 else avgGain / avgLoss
        var rsi = 100.0 - (100.0 / (1.0 + rs))
        result.add(rsi)

        for (i in (period + 1) until closes.size) {
            val change = closes[i] - closes[i - 1]
            val gain = if (change >= 0) change else 0.0
            val loss = if (change < 0) abs(change) else 0.0

            avgGain = (avgGain * (period - 1) + gain) / period
            avgLoss = (avgLoss * (period - 1) + loss) / period

            rs = if (avgLoss == 0.0) 100.0 else avgGain / avgLoss
            rsi = 100.0 - (100.0 / (1.0 + rs))
            result.add(rsi)
        }

        return result
    }

    private fun calculateBollingerBands(closes: List<Double>, period: Int = 20, k: Double = 2.0): Triple<List<Double>, List<Double>, List<Double>> {
        val upper = mutableListOf<Double>()
        val mid = mutableListOf<Double>()
        val lower = mutableListOf<Double>()

        for (i in closes.indices) {
            if (i < period - 1) {
                upper.add(closes[i])
                mid.add(closes[i])
                lower.add(closes[i])
            } else {
                val window = closes.subList(i - period + 1, i + 1)
                val mean = window.average()
                val variance = window.sumOf { (it - mean).pow(2) } / period
                val stdDev = sqrt(variance)

                mid.add(mean)
                upper.add(mean + (k * stdDev))
                lower.add(mean - (k * stdDev))
            }
        }

        return Triple(upper, mid, lower)
    }

    private fun calculatePivots(high: Double, low: Double, close: Double): PivotLevels {
        val p = (high + low + close) / 3.0
        val r1 = (2 * p) - low
        val s1 = (2 * p) - high
        val r2 = p + (high - low)
        val s2 = p - (high - low)
        val r3 = high + 2 * (p - low)
        val s3 = low - 2 * (high - p)

        return PivotLevels(
            pivot = Math.round(p * 100.0) / 100.0,
            r1 = Math.round(r1 * 100.0) / 100.0,
            r2 = Math.round(r2 * 100.0) / 100.0,
            r3 = Math.round(r3 * 100.0) / 100.0,
            s1 = Math.round(s1 * 100.0) / 100.0,
            s2 = Math.round(s2 * 100.0) / 100.0,
            s3 = Math.round(s3 * 100.0) / 100.0
        )
    }

    private fun evaluateAiSignal() {
        val candles = _activeCandles.value
        if (candles.size < 20) return

        val last = candles.last()
        val prev = candles[candles.size - 2]

        var score = 0 // -100 (Extremely Bearish) to +100 (Extremely Bullish)
        val reasons = mutableListOf<String>()

        // 1. RSI Factor
        val rsi = last.rsi14 ?: 50.0
        if (rsi < 28.0) {
            score += 40
            reasons.add("RSI Oversold ($rsi)")
        } else if (rsi < 40.0) {
            score += 15
            reasons.add("RSI Low ($rsi)")
        } else if (rsi > 72.0) {
            score -= 40
            reasons.add("RSI Overbought ($rsi)")
        } else if (rsi > 60.0) {
            score -= 15
            reasons.add("RSI Elevated ($rsi)")
        }

        // 2. EMA Trend Alignment
        val ema9 = last.ema9 ?: currentPrice
        val ema21 = last.ema21 ?: currentPrice
        val ema50 = last.ema50 ?: currentPrice

        if (ema9 > ema21 && ema21 > ema50) {
            score += 30
            reasons.add("EMA Ribbon Bullish Alignment")
        } else if (ema9 < ema21 && ema21 < ema50) {
            score -= 30
            reasons.add("EMA Ribbon Bearish Alignment")
        }

        // 3. Bollinger Band Position
        val upperBB = last.upperBand ?: currentPrice
        val lowerBB = last.lowerBand ?: currentPrice

        if (currentPrice <= lowerBB) {
            score += 25
            reasons.add("Price touching Lower Bollinger Band")
        } else if (currentPrice >= upperBB) {
            score -= 25
            reasons.add("Price touching Upper Bollinger Band")
        }

        // 4. MACD Momentum
        val macdHist = last.macdHist ?: 0.0
        val prevHist = prev.macdHist ?: 0.0
        if (macdHist > 0 && macdHist > prevHist) {
            score += 15
        } else if (macdHist < 0 && macdHist < prevHist) {
            score -= 15
        }

        val clampedScore = score.coerceIn(-100, 100)
        val confidence = min(98, max(45, abs(clampedScore) + 20))

        val signalType = when {
            clampedScore >= 55 -> SignalType.STRONG_BUY
            clampedScore >= 25 -> SignalType.BUY
            clampedScore <= -55 -> SignalType.STRONG_SELL
            clampedScore <= -25 -> SignalType.SELL
            else -> SignalType.NEUTRAL
        }

        val reasonStr = if (reasons.isEmpty()) "Market oscillating in consolidation" else reasons.joinToString(" • ")

        val slDistance = 3.50 // $3.50 SL for Gold = 35 pips
        val tpDistance = 7.00 // $7.00 TP for Gold = 70 pips (1:2 R:R)

        val suggestedSl = if (signalType == SignalType.BUY || signalType == SignalType.STRONG_BUY) {
            Math.round((currentPrice - slDistance) * 100.0) / 100.0
        } else {
            Math.round((currentPrice + slDistance) * 100.0) / 100.0
        }

        val suggestedTp = if (signalType == SignalType.BUY || signalType == SignalType.STRONG_BUY) {
            Math.round((currentPrice + tpDistance) * 100.0) / 100.0
        } else {
            Math.round((currentPrice - tpDistance) * 100.0) / 100.0
        }

        _latestSignal.value = SignalDecision(
            type = signalType,
            score = clampedScore,
            confidence = confidence,
            reason = reasonStr,
            suggestedSl = suggestedSl,
            suggestedTp = suggestedTp,
            timestamp = System.currentTimeMillis()
        )
    }
}
