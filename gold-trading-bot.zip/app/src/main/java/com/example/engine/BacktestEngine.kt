package com.example.engine

import com.example.data.model.BacktestResult
import com.example.data.model.BacktestScenario
import com.example.data.model.BacktestTradeResult
import com.example.data.model.StrategyType
import com.example.data.model.TradeType
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

class BacktestEngine {

    fun runBacktest(
        scenario: BacktestScenario,
        strategy: StrategyType,
        initialBalance: Double = 10000.0,
        lotSize: Double = 0.50,
        slPips: Double = 25.0,
        tpPips: Double = 50.0
    ): BacktestResult {
        val trades = mutableListOf<BacktestTradeResult>()
        val equityCurve = mutableListOf<Double>()
        equityCurve.add(initialBalance)

        var currentEquity = initialBalance
        var peakEquity = initialBalance
        var maxDrawdown = 0.0

        val totalCycles = 40
        var basePrice = 2700.0

        // Determine base win probabilities and price direction based on scenario & strategy
        val (winProb, trendStep) = when (scenario) {
            BacktestScenario.BULL_RALLY -> {
                when (strategy) {
                    StrategyType.TREND_FOLLOWING -> Pair(0.78, 4.5)
                    StrategyType.BREAKOUT -> Pair(0.72, 4.5)
                    StrategyType.SCALPER -> Pair(0.65, 4.5)
                    StrategyType.GRID_BOT -> Pair(0.55, 4.5)
                    StrategyType.MANUAL -> Pair(0.60, 4.5)
                }
            }
            BacktestScenario.BEAR_DUMP -> {
                when (strategy) {
                    StrategyType.TREND_FOLLOWING -> Pair(0.74, -4.0)
                    StrategyType.BREAKOUT -> Pair(0.70, -4.0)
                    StrategyType.SCALPER -> Pair(0.62, -4.0)
                    StrategyType.GRID_BOT -> Pair(0.48, -4.0)
                    StrategyType.MANUAL -> Pair(0.58, -4.0)
                }
            }
            BacktestScenario.RANGE_BOUND -> {
                when (strategy) {
                    StrategyType.GRID_BOT -> Pair(0.82, 0.2)
                    StrategyType.SCALPER -> Pair(0.76, 0.2)
                    StrategyType.TREND_FOLLOWING -> Pair(0.48, 0.2)
                    StrategyType.BREAKOUT -> Pair(0.44, 0.2)
                    StrategyType.MANUAL -> Pair(0.55, 0.2)
                }
            }
            BacktestScenario.FED_VOLATILITY -> {
                when (strategy) {
                    StrategyType.BREAKOUT -> Pair(0.75, 1.0)
                    StrategyType.SCALPER -> Pair(0.58, 1.0)
                    StrategyType.TREND_FOLLOWING -> Pair(0.64, 1.0)
                    StrategyType.GRID_BOT -> Pair(0.42, 1.0)
                    StrategyType.MANUAL -> Pair(0.52, 1.0)
                }
            }
        }

        for (i in 1..totalCycles) {
            val isWin = Random.nextDouble() < winProb
            val isBuy = if (trendStep > 0) (Random.nextDouble() < 0.7) else (Random.nextDouble() < 0.3)
            val tradeType = if (isBuy) TradeType.BUY else TradeType.SELL

            val entry = Math.round((basePrice + Random.nextDouble(-5.0, 5.0)) * 100.0) / 100.0
            val pips = if (isWin) {
                tpPips * Random.nextDouble(0.7, 1.1)
            } else {
                -slPips * Random.nextDouble(0.8, 1.0)
            }

            val priceDiff = pips / 10.0
            val exit = if (tradeType == TradeType.BUY) entry + priceDiff else entry - priceDiff
            // 1 lot gold = $10 per pip per lot. lotSize * pips * 10
            val profit = Math.round((pips * 10.0 * lotSize) * 100.0) / 100.0

            currentEquity += profit
            if (currentEquity > peakEquity) peakEquity = currentEquity
            val currentDd = ((peakEquity - currentEquity) / peakEquity) * 100.0
            if (currentDd > maxDrawdown) maxDrawdown = currentDd

            val exitReason = if (isWin) "Take Profit (+$${profit})" else "Stop Loss (-$${abs(profit)})"

            trades.add(
                BacktestTradeResult(
                    tradeId = i,
                    type = tradeType,
                    entryPrice = entry,
                    exitPrice = Math.round(exit * 100.0) / 100.0,
                    profit = profit,
                    pips = Math.round(pips * 10.0) / 10.0,
                    isWin = isWin,
                    exitReason = exitReason,
                    cumulativeEquity = Math.round(currentEquity * 100.0) / 100.0
                )
            )

            equityCurve.add(Math.round(currentEquity * 100.0) / 100.0)
            basePrice += (trendStep * 0.8) + Random.nextDouble(-2.0, 2.0)
        }

        val winningTrades = trades.count { it.isWin }
        val losingTrades = trades.size - winningTrades
        val grossProfit = trades.filter { it.profit > 0 }.sumOf { it.profit }
        val grossLoss = abs(trades.filter { it.profit < 0 }.sumOf { it.profit })
        val profitFactor = if (grossLoss == 0.0) grossProfit else grossProfit / grossLoss

        return BacktestResult(
            scenario = scenario,
            strategy = strategy,
            initialBalance = initialBalance,
            finalBalance = Math.round(currentEquity * 100.0) / 100.0,
            netProfit = Math.round((currentEquity - initialBalance) * 100.0) / 100.0,
            totalTrades = trades.size,
            winningTrades = winningTrades,
            losingTrades = losingTrades,
            winRate = Math.round((winningTrades.toDouble() / trades.size * 100.0) * 10.0) / 10.0,
            profitFactor = Math.round(profitFactor * 100.0) / 100.0,
            maxDrawdownPercent = Math.round(maxDrawdown * 100.0) / 100.0,
            bestTrade = trades.maxOfOrNull { it.profit } ?: 0.0,
            worstTrade = trades.minOfOrNull { it.profit } ?: 0.0,
            trades = trades,
            equityCurve = equityCurve
        )
    }
}
