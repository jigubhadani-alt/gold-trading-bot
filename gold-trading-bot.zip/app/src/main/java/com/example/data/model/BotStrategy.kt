package com.example.data.model

enum class SignalType {
    STRONG_BUY,
    BUY,
    NEUTRAL,
    SELL,
    STRONG_SELL
}

data class SignalDecision(
    val type: SignalType,
    val score: Int, // -100 to +100
    val confidence: Int, // 0 to 100%
    val reason: String,
    val suggestedSl: Double,
    val suggestedTp: Double,
    val timestamp: Long = System.currentTimeMillis()
)

data class BotStrategyConfig(
    val type: StrategyType,
    val isEnabled: Boolean = true,
    val defaultLotSize: Double = 0.50,
    val stopLossPips: Double = 25.0,
    val takeProfitPips: Double = 50.0,
    val trailingStopEnabled: Boolean = true,
    val trailingStopPips: Double = 15.0,
    val winCount: Int = 0,
    val lossCount: Int = 0,
    val totalProfit: Double = 0.0
) {
    val winRate: Double
        get() {
            val total = winCount + lossCount
            return if (total == 0) 0.0 else (winCount.toDouble() / total) * 100.0
        }
}

enum class LogLevel {
    INFO,
    SIGNAL,
    TRADE,
    SUCCESS,
    WARNING
}

data class BotLog(
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val message: String,
    val level: LogLevel = LogLevel.INFO,
    val strategy: StrategyType? = null
)
