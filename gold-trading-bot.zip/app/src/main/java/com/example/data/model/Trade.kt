package com.example.data.model

enum class TradeType {
    BUY,
    SELL
}

enum class TradeStatus {
    OPEN,
    CLOSED,
    CANCELLED
}

enum class StrategyType(val titleEn: String, val titleGu: String) {
    SCALPER("Gold Scalper (RSI+BB)", "ગોલ્ડ સ્કેલ્પર (RSI+BB)"),
    TREND_FOLLOWING("Golden Trend (EMA Ribbon)", "ગોલ્ડન ટ્રેન્ડ (EMA)"),
    GRID_BOT("Grid Accumulator", "ગ્રીડ એક્યુમ્યુલેટર"),
    BREAKOUT("Volatility Breakout", "વોલેટિલિટી બ્રેકઆઉટ"),
    MANUAL("Manual Trade", "મેન્યુઅલ ટ્રેડ")
}

data class Trade(
    val id: Long = 0,
    val ticketNumber: String,
    val type: TradeType,
    val symbol: String = "XAU/USD",
    val lotSize: Double,
    val entryPrice: Double,
    val currentPrice: Double = entryPrice,
    val exitPrice: Double? = null,
    val stopLoss: Double,
    val takeProfit: Double,
    val pnl: Double = 0.0,
    val pips: Double = 0.0,
    val status: TradeStatus = TradeStatus.OPEN,
    val openTime: Long = System.currentTimeMillis(),
    val closeTime: Long? = null,
    val strategy: StrategyType = StrategyType.SCALPER,
    val closeReason: String? = null,
    val isTrailingEnabled: Boolean = true,
    val highestPriceReached: Double = entryPrice,
    val lowestPriceReached: Double = entryPrice
)
