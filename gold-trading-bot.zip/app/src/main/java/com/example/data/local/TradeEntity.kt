package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.StrategyType
import com.example.data.model.Trade
import com.example.data.model.TradeStatus
import com.example.data.model.TradeType

@Entity(tableName = "trades")
data class TradeEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val ticketNumber: String,
    val type: String, // BUY, SELL
    val symbol: String = "XAU/USD",
    val lotSize: Double,
    val entryPrice: Double,
    val exitPrice: Double? = null,
    val stopLoss: Double,
    val takeProfit: Double,
    val pnl: Double = 0.0,
    val pips: Double = 0.0,
    val status: String, // OPEN, CLOSED, CANCELLED
    val openTime: Long,
    val closeTime: Long? = null,
    val strategy: String,
    val closeReason: String? = null
) {
    fun toDomain(currentPrice: Double = entryPrice): Trade {
        val tradeType = try { TradeType.valueOf(type) } catch (e: Exception) { TradeType.BUY }
        val tradeStatus = try { TradeStatus.valueOf(status) } catch (e: Exception) { TradeStatus.OPEN }
        val stratType = try { StrategyType.valueOf(strategy) } catch (e: Exception) { StrategyType.SCALPER }
        
        val livePnl = if (tradeStatus == TradeStatus.OPEN) {
            val priceDiff = if (tradeType == TradeType.BUY) currentPrice - entryPrice else entryPrice - currentPrice
            // 1 standard lot Gold = 100 oz. Price diff * 100 * lotSize = USD P&L
            priceDiff * 100.0 * lotSize
        } else {
            pnl
        }

        val livePips = if (tradeStatus == TradeStatus.OPEN) {
            val diff = if (tradeType == TradeType.BUY) currentPrice - entryPrice else entryPrice - currentPrice
            diff * 10.0 // 1 pip = $0.10 in gold
        } else {
            pips
        }

        return Trade(
            id = id,
            ticketNumber = ticketNumber,
            type = tradeType,
            symbol = symbol,
            lotSize = lotSize,
            entryPrice = entryPrice,
            currentPrice = if (tradeStatus == TradeStatus.OPEN) currentPrice else (exitPrice ?: entryPrice),
            exitPrice = exitPrice,
            stopLoss = stopLoss,
            takeProfit = takeProfit,
            pnl = livePnl,
            pips = livePips,
            status = tradeStatus,
            openTime = openTime,
            closeTime = closeTime,
            strategy = stratType,
            closeReason = closeReason
        )
    }

    companion object {
        fun fromDomain(trade: Trade): TradeEntity {
            return TradeEntity(
                id = trade.id,
                ticketNumber = trade.ticketNumber,
                type = trade.type.name,
                symbol = trade.symbol,
                lotSize = trade.lotSize,
                entryPrice = trade.entryPrice,
                exitPrice = trade.exitPrice,
                stopLoss = trade.stopLoss,
                takeProfit = trade.takeProfit,
                pnl = trade.pnl,
                pips = trade.pips,
                status = trade.status.name,
                openTime = trade.openTime,
                closeTime = trade.closeTime,
                strategy = trade.strategy.name,
                closeReason = trade.closeReason
            )
        }
    }
}
