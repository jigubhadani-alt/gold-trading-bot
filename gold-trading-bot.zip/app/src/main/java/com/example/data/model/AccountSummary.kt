package com.example.data.model

data class AccountSummary(
    val balance: Double = 10000.0,
    val equity: Double = 10000.0,
    val marginUsed: Double = 0.0,
    val freeMargin: Double = 10000.0,
    val marginLevelPercent: Double = 0.0,
    val floatingPnl: Double = 0.0,
    val totalRealizedProfit: Double = 0.0,
    val totalTrades: Int = 0,
    val winningTrades: Int = 0,
    val losingTrades: Int = 0,
    val profitFactor: Double = 0.0,
    val bestTrade: Double = 0.0,
    val worstTrade: Double = 0.0
) {
    val winRate: Double
        get() = if (totalTrades == 0) 0.0 else (winningTrades.toDouble() / totalTrades) * 100.0
}

enum class BacktestScenario(val titleEn: String, val titleGu: String, val description: String) {
    BULL_RALLY("Bullish Super-Rally (+8.5%)", "તેજીની મહારેલી (+8.5%)", "Gold moves from $2,650 to $2,875 with healthy pullbacks."),
    BEAR_DUMP("Bearish Liquidity Dump (-6.2%)", "મંદીનો મોટો ઘટાડો (-6.2%)", "Aggressive sell-off driven by strong Dollar & higher yields."),
    RANGE_BOUND("Sideways Consolidation", "રેન્જ બાઉન્ડ સાઇડવેઝ માર્કેટ", "Gold ranges tightly between $2,720 and $2,755 for days."),
    FED_VOLATILITY("Fed News Volatility Spike", "ન્યુઝ વોલેટિલિટી સ્પાઇક", "Intense multi-directional whipsaws with expanded ATR.")
}

data class BacktestTradeResult(
    val tradeId: Int,
    val type: TradeType,
    val entryPrice: Double,
    val exitPrice: Double,
    val profit: Double,
    val pips: Double,
    val isWin: Boolean,
    val exitReason: String,
    val cumulativeEquity: Double
)

data class BacktestResult(
    val scenario: BacktestScenario,
    val strategy: StrategyType,
    val initialBalance: Double,
    val finalBalance: Double,
    val netProfit: Double,
    val totalTrades: Int,
    val winningTrades: Int,
    val losingTrades: Int,
    val winRate: Double,
    val profitFactor: Double,
    val maxDrawdownPercent: Double,
    val bestTrade: Double,
    val worstTrade: Double,
    val trades: List<BacktestTradeResult>,
    val equityCurve: List<Double>
)
