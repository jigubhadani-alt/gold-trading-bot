package com.example.data.model

enum class AppLanguage(val code: String, val displayName: String, val nativeName: String) {
    ENGLISH("en", "English", "English"),
    GUJARATI("gu", "Gujarati", "ગુજરાતી")
}

object AppStrings {
    private val en = mapOf(
        "app_title" to "Gold Trading Bot (XAU/USD)",
        "tab_bot" to "Bot & Signals",
        "tab_chart" to "Live Chart",
        "tab_positions" to "Trades",
        "tab_backtest" to "Backtest",
        "tab_settings" to "Settings",
        
        "bot_status_active" to "AUTOMATED BOT ACTIVE",
        "bot_status_paused" to "BOT PAUSED (MANUAL MODE)",
        "bot_toggle_start" to "Activate Auto Bot",
        "bot_toggle_stop" to "Pause Bot",
        "bot_speed" to "Sim Speed",
        
        "live_price" to "XAU/USD Live Price",
        "spread" to "Spread",
        "high_24h" to "24h High",
        "low_24h" to "24h Low",
        "change_24h" to "24h Change",
        
        "ai_signal" to "AI Signal Radar",
        "signal_strong_buy" to "STRONG BUY",
        "signal_buy" to "BUY",
        "signal_neutral" to "NEUTRAL / HOLD",
        "signal_sell" to "SELL",
        "signal_strong_sell" to "STRONG SELL",
        "signal_confidence" to "Signal Confidence",
        
        "quick_order" to "Quick Order Execution",
        "btn_buy" to "BUY GOLD (XAU)",
        "btn_sell" to "SELL GOLD (XAU)",
        "lot_size" to "Lot Size",
        "sl_pips" to "Stop Loss (Pips)",
        "tp_pips" to "Take Profit (Pips)",
        
        "strategies_title" to "Trading Bot Strategies",
        "strat_scalper" to "Gold Scalper Pro (RSI + Bollinger)",
        "strat_scalper_desc" to "Fast 1M/5M mean-reversion catching overbought/oversold gold swings.",
        "strat_trend" to "Golden Trend (EMA 9/21 Ribbon)",
        "strat_trend_desc" to "Rides sustained multi-pip gold momentum with dynamic trailing stop-loss.",
        "strat_grid" to "Gold Grid Accumulator",
        "strat_grid_desc" to "Places automated multi-level buy/sell mesh across gold consolidation ranges.",
        "strat_breakout" to "Volatility Spike & Breakout",
        "strat_breakout_desc" to "Detects high-volume explosive gold surges around economic news.",
        
        "active_strategies" to "Active Bots",
        "bot_logs" to "Live Bot Log & Activity",
        "clear_logs" to "Clear Logs",
        
        "account_balance" to "Balance",
        "account_equity" to "Equity",
        "account_pnl" to "Floating P&L",
        "margin_free" to "Free Margin",
        "margin_level" to "Margin Level",
        "win_rate" to "Win Rate",
        "total_trades" to "Total Trades",
        "net_profit" to "Net Profit",
        "profit_factor" to "Profit Factor",
        
        "open_positions" to "Open Positions",
        "trade_history" to "Trade History",
        "no_open_positions" to "No active open positions. Bot is scanning the gold market...",
        "no_history" to "No closed trades yet. Automated trades will appear here.",
        "close_trade" to "Close",
        "close_all" to "Close All Positions",
        
        "timeframe" to "Timeframe",
        "indicators" to "Indicators",
        "pivot_levels" to "Floor Pivot Levels",
        "resistance" to "Resistance",
        "support" to "Support",
        
        "backtest_title" to "Strategy Backtesting Lab",
        "backtest_desc" to "Simulate bot algorithms against historical gold market regimes.",
        "select_scenario" to "Market Scenario",
        "scenario_bull" to "Bullish Super-Rally (+8.5%)",
        "scenario_bear" to "Bearish Liquidity Dump (-6.2%)",
        "scenario_chop" to "Sideways Range Consolidation",
        "scenario_volatility" to "High-Impact Fed News Spike",
        "run_backtest" to "Run 30-Day Backtest",
        "backtesting" to "Backtesting Strategy...",
        "backtest_results" to "Backtest Performance Report",
        "max_drawdown" to "Max Drawdown",
        "best_trade" to "Best Trade",
        "worst_trade" to "Worst Trade",
        
        "settings_title" to "Bot Configuration & Risk Guard",
        "risk_percent" to "Risk Per Trade (%)",
        "max_daily_loss" to "Daily Drawdown Stop Limit ($)",
        "max_open_trades" to "Max Concurrent Trades",
        "trailing_stop" to "Trailing Stop-Loss",
        "sound_haptic" to "Haptic Feedback on Signals",
        "language_select" to "App Language (ભાષા)",
        "reset_account" to "Reset Demo Capital",
        "reset_success" to "Trading account reset to $10,000"
    )

    private val gu = mapOf(
        "app_title" to "ગોલ્ડ ટ્રેડિંગ બોટ (XAU/USD)",
        "tab_bot" to "બોટ & સિગ્નલ",
        "tab_chart" to "લાઈવ ચાર્ટ",
        "tab_positions" to "ટ્રેડ્સ",
        "tab_backtest" to "બેકટેસ્ટિંગ",
        "tab_settings" to "સેટિંગ્સ",
        
        "bot_status_active" to "ઓટોમેટેડ બોટ સક્રિય છે",
        "bot_status_paused" to "બોટ બંધ છે (મેન્યુઅલ મોડ)",
        "bot_toggle_start" to "ઓટો બોટ ચાલુ કરો",
        "bot_toggle_stop" to "બોટ થોભાવો",
        "bot_speed" to "સિમ સ્પીડ",
        
        "live_price" to "XAU/USD સોનાનો લાઈવ ભાવ",
        "spread" to "સ્પ્રેડ",
        "high_24h" to "24 કલાક હાઈ",
        "low_24h" to "24 કલાક લો",
        "change_24h" to "24 કલાક ફેરફાર",
        
        "ai_signal" to "AI સિગ્નલ રડાર",
        "signal_strong_buy" to "મજબૂત ખરીદી (STRONG BUY)",
        "signal_buy" to "ખરીદો (BUY)",
        "signal_neutral" to "તટસ્થ / હોલ્ડ (NEUTRAL)",
        "signal_sell" to "વેચો (SELL)",
        "signal_strong_sell" to "મજબૂત વેચાણ (STRONG SELL)",
        "signal_confidence" to "સિગ્નલ ચોકસાઈ (Confidence)",
        
        "quick_order" to "ઝડપી ટ્રેડ એન્ટ્રી (Manual Trade)",
        "btn_buy" to "સોનું ખરીદો (BUY GOLD)",
        "btn_sell" to "સોનું વેચો (SELL GOLD)",
        "lot_size" to "લોટ સાઇઝ (Lot Size)",
        "sl_pips" to "સ્ટોપ લોસ પિપ્સ (SL)",
        "tp_pips" to "ટેક પ્રોફિટ પિપ્સ (TP)",
        
        "strategies_title" to "બોટ ટ્રેડિંગ રણનીતિઓ (Strategies)",
        "strat_scalper" to "ગોલ્ડ સ્કેલ્પર પ્રો (RSI + Bollinger)",
        "strat_scalper_desc" to "1M/5M માં ઝડપી સોનાના રિવર્સલ અને સ્પાઇક્સ પકડે છે.",
        "strat_trend" to "ગોલ્ડન ટ્રેન્ડ (EMA 9/21 રીબન)",
        "strat_trend_desc" to "ટ્રેલિંગ સ્ટોપ લોસ સાથે મોટી તેજી/મંદીની રેલી પકડે છે.",
        "strat_grid" to "ગોલ્ડ ગ્રીડ એક્યુમ્યુલેટર",
        "strat_grid_desc" to "રેન્જ માર્કેટમાં આપમેળે નીચે ખરીદી ઉપર વેચાણ કરે છે.",
        "strat_breakout" to "વોલેટિલિટી બ્રેકઆઉટ હન્ટર",
        "strat_breakout_desc" to "મોટા ન્યુઝ અને વોલ્યુમ બ્રેકઆઉટમાં ઝડપી નફો બુક કરે છે.",
        
        "active_strategies" to "સક્રિય બોટ્સ",
        "bot_logs" to "લાઈવ બોટ પ્રવૃત્તિ લૉગ્સ",
        "clear_logs" to "લૉગ્સ સાફ કરો",
        
        "account_balance" to "સિલક (બેલેન્સ)",
        "account_equity" to "ઇક્વિટી",
        "account_pnl" to "ચાલુ નફો/નુકસાન",
        "margin_free" to "ફ્રી માર્જિન",
        "margin_level" to "માર્જિન લેવલ",
        "win_rate" to "વિન રેટ (%)",
        "total_trades" to "કુલ ટ્રેડ્સ",
        "net_profit" to "ચોખ્ખો નફો",
        "profit_factor" to "પ્રોફિટ ફેક્ટર",
        
        "open_positions" to "ચાલુ ઓપન ટ્રેડ્સ",
        "trade_history" to "ટ્રેડિંગ ઇતિહાસ",
        "no_open_positions" to "હાલમાં કોઈ ઓપન ટ્રેડ નથી. બોટ સોનાના બજારનું વિશ્લેષણ કરે છે...",
        "no_history" to "હજુ સુધી કોઈ પૂર્ણ ટ્રેડ નથી. બોટ ટ્રેડ્સ અહીં દેખાશે.",
        "close_trade" to "ટ્રેડ બંધ કરો",
        "close_all" to "બધા ટ્રેડ્સ બંધ કરો",
        
        "timeframe" to "ટાઈમફ્રેમ",
        "indicators" to "ઈન્ડીકેટર્સ",
        "pivot_levels" to "ડેઇલી પિવોટ લેવલ્સ",
        "resistance" to "રેઝિસ્ટન્સ (અવરોધ)",
        "support" to "સપોર્ટ (ટેકો)",
        
        "backtest_title" to "બોટ બેકટેસ્ટિંગ લેબ",
        "backtest_desc" to "ઐતિહાસિક સોનાના માર્કેટ ડેટા પર બોટનું પ્રદર્શન ચકાસો.",
        "select_scenario" to "માર્કેટ પરિસ્થિતિ (Scenario)",
        "scenario_bull" to "તેજીની મહારેલી (+8.5% Bull Rally)",
        "scenario_bear" to "મંદીનો મોટો ઘટાડો (-6.2% Bear Dump)",
        "scenario_chop" to "રેન્જ બાઉન્ડ સાઇડવેઝ માર્કેટ",
        "scenario_volatility" to "ન્યુઝ વોલેટિલિટી સ્પાઇક",
        "run_backtest" to "30-દિવસ બેકટેસ્ટ શરૂ કરો",
        "backtesting" to "બેકટેસ્ટિંગ ચાલે છે...",
        "backtest_results" to "બેકટેસ્ટિંગ રિપોર્ટ પરિણામ",
        "max_drawdown" to "મહત્તમ ડ્રોડાઉન (Max DD)",
        "best_trade" to "શ્રેષ્ઠ ટ્રેડ",
        "worst_trade" to "સૌથી મોટો લોસ ટ્રેડ",
        
        "settings_title" to "બોટ સેટિંગ્સ અને જોખમ નિયંત્રણ",
        "risk_percent" to "ટ્રેડ દીઠ જોખમ (%)",
        "max_daily_loss" to "દૈનિક સ્ટોપ લિમિટ ($)",
        "max_open_trades" to "મહત્તમ એકસાથે ટ્રેડ્સ",
        "trailing_stop" to "ટ્રેલિંગ સ્ટોપ-લોસ (Trailing SL)",
        "sound_haptic" to "સિગ્નલ પર વાઇબ્રેશન",
        "language_select" to "એપ ભાષા બદલો (Language)",
        "reset_account" to "ડેમો મૂડી રિસેટ કરો",
        "reset_success" to "ટ્રેડિંગ એકાઉન્ટ $10,000 પર રિસેટ થયું"
    )

    fun get(key: String, language: AppLanguage): String {
        val map = if (language == AppLanguage.GUJARATI) gu else en
        return map[key] ?: en[key] ?: key
    }
}
