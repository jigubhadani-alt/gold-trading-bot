package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface BotLogDao {
    @Query("SELECT * FROM bot_logs ORDER BY timestamp DESC LIMIT 100")
    fun getRecentLogs(): Flow<List<BotLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: BotLogEntity): Long

    @Query("DELETE FROM bot_logs")
    suspend fun clearLogs()
}
