package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.BotLogEntity
import com.example.data.local.TradeEntity
import com.example.data.model.BotLog
import com.example.data.model.Trade
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class TradingRepository(private val db: AppDatabase) {

    val openTrades: Flow<List<TradeEntity>> = db.tradeDao().getOpenTrades()
    val closedTrades: Flow<List<TradeEntity>> = db.tradeDao().getClosedTrades()
    val allTrades: Flow<List<TradeEntity>> = db.tradeDao().getAllTrades()
    val recentLogs: Flow<List<BotLog>> = db.botLogDao().getRecentLogs().map { list ->
        list.map { it.toDomain() }
    }

    suspend fun openTrade(trade: Trade): Long {
        val entity = TradeEntity.fromDomain(trade)
        return db.tradeDao().insertTrade(entity)
    }

    suspend fun updateTrade(trade: Trade) {
        val entity = TradeEntity.fromDomain(trade)
        db.tradeDao().updateTrade(entity)
    }

    suspend fun closeTrade(id: Long, exitPrice: Double, pnl: Double, pips: Double, reason: String) {
        db.tradeDao().closeTrade(
            id = id,
            exitPrice = exitPrice,
            pnl = pnl,
            pips = pips,
            closeTime = System.currentTimeMillis(),
            reason = reason
        )
    }

    suspend fun logBotActivity(log: BotLog): Long {
        return db.botLogDao().insertLog(BotLogEntity.fromDomain(log))
    }

    suspend fun clearLogs() {
        db.botLogDao().clearLogs()
    }

    suspend fun resetAllTrades() {
        db.tradeDao().deleteAllTrades()
        db.botLogDao().clearLogs()
    }
}
