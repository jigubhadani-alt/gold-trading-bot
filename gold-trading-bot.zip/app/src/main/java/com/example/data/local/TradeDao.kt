package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface TradeDao {
    @Query("SELECT * FROM trades WHERE status = 'OPEN' ORDER BY openTime DESC")
    fun getOpenTrades(): Flow<List<TradeEntity>>

    @Query("SELECT * FROM trades WHERE status = 'CLOSED' ORDER BY closeTime DESC")
    fun getClosedTrades(): Flow<List<TradeEntity>>

    @Query("SELECT * FROM trades ORDER BY openTime DESC")
    fun getAllTrades(): Flow<List<TradeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrade(trade: TradeEntity): Long

    @Update
    suspend fun updateTrade(trade: TradeEntity)

    @Query("UPDATE trades SET status = 'CLOSED', exitPrice = :exitPrice, pnl = :pnl, pips = :pips, closeTime = :closeTime, closeReason = :reason WHERE id = :id")
    suspend fun closeTrade(id: Long, exitPrice: Double, pnl: Double, pips: Double, closeTime: Long, reason: String)

    @Query("DELETE FROM trades")
    suspend fun deleteAllTrades()
}
