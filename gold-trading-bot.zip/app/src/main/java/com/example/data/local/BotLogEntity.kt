package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.BotLog
import com.example.data.model.LogLevel
import com.example.data.model.StrategyType

@Entity(tableName = "bot_logs")
data class BotLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long,
    val message: String,
    val level: String, // INFO, SIGNAL, TRADE, SUCCESS, WARNING
    val strategy: String? = null
) {
    fun toDomain(): BotLog {
        val logLevel = try { LogLevel.valueOf(level) } catch (e: Exception) { LogLevel.INFO }
        val stratType = strategy?.let { try { StrategyType.valueOf(it) } catch (e: Exception) { null } }
        return BotLog(
            id = id,
            timestamp = timestamp,
            message = message,
            level = logLevel,
            strategy = stratType
        )
    }

    companion object {
        fun fromDomain(log: BotLog): BotLogEntity {
            return BotLogEntity(
                id = log.id,
                timestamp = log.timestamp,
                message = log.message,
                level = log.level.name,
                strategy = log.strategy?.name
            )
        }
    }
}
