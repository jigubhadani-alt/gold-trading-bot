package com.example.data.model

enum class Timeframe(val label: String, val seconds: Long) {
    M1("1M", 60),
    M5("5M", 300),
    M15("15M", 900),
    H1("1H", 3600),
    H4("4H", 14400),
    D1("1D", 86400)
}

data class CandleStick(
    val timestamp: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double,
    val ema9: Double? = null,
    val ema21: Double? = null,
    val ema50: Double? = null,
    val rsi14: Double? = null,
    val upperBand: Double? = null,
    val middleBand: Double? = null,
    val lowerBand: Double? = null,
    val macd: Double? = null,
    val macdSignal: Double? = null,
    val macdHist: Double? = null
)

data class MarketTick(
    val symbol: String = "XAU/USD",
    val price: Double,
    val bid: Double,
    val ask: Double,
    val spread: Double,
    val change24h: Double,
    val changePercent24h: Double,
    val high24h: Double,
    val low24h: Double,
    val volume24h: Double,
    val timestamp: Long = System.currentTimeMillis()
)

data class PivotLevels(
    val pivot: Double,
    val r1: Double,
    val r2: Double,
    val r3: Double,
    val s1: Double,
    val s2: Double,
    val s3: Double
)
