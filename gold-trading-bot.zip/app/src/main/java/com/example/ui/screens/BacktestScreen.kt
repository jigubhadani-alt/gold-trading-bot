package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppStrings
import com.example.data.model.BacktestResult
import com.example.data.model.BacktestScenario
import com.example.data.model.StrategyType
import com.example.data.model.TradeType
import com.example.ui.theme.BgTerminal
import com.example.ui.theme.BlueEma
import com.example.ui.theme.CardBorderTerminal
import com.example.ui.theme.CardTerminal
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GreenBull
import com.example.ui.theme.GreenBullBg
import com.example.ui.theme.RedBear
import com.example.ui.theme.RedBearBg
import com.example.ui.theme.SurfaceTerminal
import com.example.ui.theme.TextGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.TradingViewModel
import java.util.Locale

@Composable
fun BacktestScreen(
    viewModel: TradingViewModel,
    modifier: Modifier = Modifier
) {
    val language by viewModel.language.collectAsStateWithLifecycle()
    val backtestResult by viewModel.backtestResult.collectAsStateWithLifecycle()
    val isBacktesting by viewModel.isBacktesting.collectAsStateWithLifecycle()

    var selectedScenario by remember { mutableStateOf(BacktestScenario.BULL_RALLY) }
    var selectedStrategy by remember { mutableStateOf(StrategyType.TREND_FOLLOWING) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BgTerminal)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Spacer(modifier = Modifier.height(6.dp)) }

        // Header
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardTerminal),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorderTerminal))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Analytics, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(22.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = AppStrings.get("backtest_title", language),
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = AppStrings.get("backtest_desc", language),
                        style = TextStyle(color = TextSecondary, fontSize = 12.sp)
                    )
                }
            }
        }

        // Strategy Selector Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CardTerminal),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorderTerminal))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "1. Choose Bot Algorithm",
                        style = TextStyle(color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    val strategies = listOf(
                        StrategyType.TREND_FOLLOWING,
                        StrategyType.SCALPER,
                        StrategyType.GRID_BOT,
                        StrategyType.BREAKOUT
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        strategies.forEach { strat ->
                            val isSelected = strat == selectedStrategy
                            val stratName = if (language == com.example.data.model.AppLanguage.GUJARATI) strat.titleGu else strat.titleEn
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) SurfaceTerminal else Color.Transparent)
                                    .border(
                                        1.dp,
                                        if (isSelected) GoldPrimary else CardBorderTerminal,
                                        RoundedCornerShape(8.dp)
                                    )
                                    .clickable { selectedStrategy = strat }
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = stratName,
                                    style = TextStyle(
                                        color = if (isSelected) GoldPrimary else TextSecondary,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 12.sp
                                    )
                                )
                                if (isSelected) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }

        // Scenario Selector Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CardTerminal),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorderTerminal))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "2. " + AppStrings.get("select_scenario", language),
                        style = TextStyle(color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    BacktestScenario.values().forEach { scenario ->
                        val isSelected = scenario == selectedScenario
                        val scName = if (language == com.example.data.model.AppLanguage.GUJARATI) scenario.titleGu else scenario.titleEn
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) SurfaceTerminal else Color.Transparent)
                                .border(
                                    1.dp,
                                    if (isSelected) BlueEma else CardBorderTerminal,
                                    RoundedCornerShape(8.dp)
                                )
                                .clickable { selectedScenario = scenario }
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = scName,
                                    style = TextStyle(
                                        color = if (isSelected) BlueEma else TextSecondary,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 12.sp
                                    )
                                )
                                Text(
                                    text = scenario.description,
                                    style = TextStyle(color = TextMuted, fontSize = 10.sp)
                                )
                            }
                            if (isSelected) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = BlueEma, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }

        // Run Button
        item {
            Button(
                onClick = {
                    viewModel.runBacktest(
                        scenario = selectedScenario,
                        strategy = selectedStrategy
                    )
                },
                enabled = !isBacktesting,
                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary, contentColor = BgTerminal),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
            ) {
                if (isBacktesting) {
                    CircularProgressIndicator(color = BgTerminal, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(text = AppStrings.get("backtesting", language), fontWeight = FontWeight.Bold)
                } else {
                    Icon(Icons.Default.PlayArrow, contentDescription = null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = AppStrings.get("run_backtest", language), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }

        // Backtest Performance Report View
        backtestResult?.let { result ->
            item {
                Text(
                    text = AppStrings.get("backtest_results", language),
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    ),
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            // Overview Metrics Card
            item {
                val isProfit = result.netProfit >= 0
                val profitColor = if (isProfit) GreenBull else RedBear
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CardTerminal),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorderTerminal))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Net Simulated Profit", style = TextStyle(color = TextSecondary, fontSize = 12.sp))
                                Text(
                                    "${if (isProfit) "+" else ""}$${String.format(Locale.US, "%,.2f", result.netProfit)}",
                                    style = TextStyle(
                                        color = profitColor,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 22.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text("Ending Equity", style = TextStyle(color = TextSecondary, fontSize = 12.sp))
                                Text(
                                    "$${String.format(Locale.US, "%,.2f", result.finalBalance)}",
                                    style = TextStyle(color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp, fontFamily = FontFamily.Monospace)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // 4-Quadrant Metric Grid
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(SurfaceTerminal, RoundedCornerShape(10.dp))
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(AppStrings.get("win_rate", language), style = TextStyle(color = TextMuted, fontSize = 11.sp))
                                Text(
                                    "${result.winRate}% (${result.winningTrades}W/${result.losingTrades}L)",
                                    style = TextStyle(color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                                )
                            }
                            Column {
                                Text(AppStrings.get("profit_factor", language), style = TextStyle(color = TextMuted, fontSize = 11.sp))
                                Text(
                                    String.format(Locale.US, "%.2f", result.profitFactor),
                                    style = TextStyle(color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                                )
                            }
                            Column {
                                Text(AppStrings.get("max_drawdown", language), style = TextStyle(color = TextMuted, fontSize = 11.sp))
                                Text(
                                    "-${String.format(Locale.US, "%.1f", result.maxDrawdownPercent)}%",
                                    style = TextStyle(color = RedBear, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                                )
                            }
                        }
                    }
                }
            }

            // Equity Curve Canvas Chart
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CardTerminal),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorderTerminal))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Equity Growth Curve",
                                style = TextStyle(color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            )
                            Text(
                                text = "40 Trades Execution",
                                style = TextStyle(color = TextMuted, fontSize = 11.sp)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Canvas(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(140.dp)
                        ) {
                            val curve = result.equityCurve
                            if (curve.size < 2) return@Canvas

                            val minEq = (curve.minOrNull() ?: 10000.0) * 0.98
                            val maxEq = (curve.maxOrNull() ?: 10000.0) * 1.02
                            val range = (maxEq - minEq).coerceAtLeast(1.0)

                            val stepX = size.width / (curve.size - 1)
                            val path = Path()

                            curve.forEachIndexed { i, eq ->
                                val x = i * stepX
                                val y = (size.height * (1f - ((eq - minEq) / range))).toFloat()
                                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                            }

                            drawPath(
                                path = path,
                                color = if (result.netProfit >= 0) GreenBull else RedBear,
                                style = Stroke(width = 2.5f, cap = StrokeCap.Round)
                            )

                            // Initial baseline
                            val baselineY = (size.height * (1f - ((result.initialBalance - minEq) / range))).toFloat()
                            drawLine(
                                color = TextMuted.copy(alpha = 0.4f),
                                start = Offset(0f, baselineY),
                                end = Offset(size.width, baselineY),
                                strokeWidth = 1f
                            )
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(80.dp)) }
    }
}
