package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppLanguage
import com.example.data.model.AppStrings
import com.example.ui.theme.BgTerminal
import com.example.ui.theme.BlueEma
import com.example.ui.theme.CardBorderTerminal
import com.example.ui.theme.CardTerminal
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GoldSecondary
import com.example.ui.theme.GreenBull
import com.example.ui.theme.RedBear
import com.example.ui.theme.RedBearBg
import com.example.ui.theme.SurfaceTerminal
import com.example.ui.theme.TextGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.TradingViewModel
import java.util.Locale

@Composable
fun SettingsRiskScreen(
    viewModel: TradingViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val language by viewModel.language.collectAsStateWithLifecycle()
    val riskPercent by viewModel.riskPercent.collectAsStateWithLifecycle()
    val maxDailyLoss by viewModel.maxDailyLoss.collectAsStateWithLifecycle()
    val maxOpenTrades by viewModel.botEngine.maxOpenTrades.collectAsStateWithLifecycle()

    var trailingStopEnabled by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BgTerminal)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Spacer(modifier = Modifier.height(6.dp)) }

        // Screen Header
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardTerminal),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorderTerminal))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = AppStrings.get("settings_title", language),
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }
                }
            }
        }

        // Language Switcher (English vs ગુજરાતી)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CardTerminal),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorderTerminal))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Language, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = AppStrings.get("language_select", language),
                            style = TextStyle(color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        AppLanguage.values().forEach { lang ->
                            val isSelected = lang == language
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (isSelected) GoldPrimary else SurfaceTerminal)
                                    .clickable { viewModel.setLanguage(lang) }
                                    .padding(vertical = 10.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${lang.displayName} (${lang.nativeName})",
                                    style = TextStyle(
                                        color = if (isSelected) BgTerminal else TextSecondary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        // Risk Parameters Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CardTerminal),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorderTerminal))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Tune, contentDescription = null, tint = BlueEma, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Auto-Trading Risk Controls",
                            style = TextStyle(color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Risk per Trade Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = AppStrings.get("risk_percent", language), style = TextStyle(color = TextSecondary, fontSize = 12.sp))
                        Text(text = "${String.format(Locale.US, "%.1f", riskPercent)}%", style = TextStyle(color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp, fontFamily = FontFamily.Monospace))
                    }
                    Slider(
                        value = riskPercent.toFloat(),
                        onValueChange = { viewModel.updateRiskPercent(Math.round(it * 10.0) / 10.0) },
                        valueRange = 0.5f..5.0f,
                        steps = 8,
                        colors = SliderDefaults.colors(thumbColor = GoldPrimary, activeTrackColor = GoldPrimary, inactiveTrackColor = SurfaceTerminal)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Max Daily Loss Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = AppStrings.get("max_daily_loss", language), style = TextStyle(color = TextSecondary, fontSize = 12.sp))
                        Text(text = "$${maxDailyLoss.toInt()}", style = TextStyle(color = RedBear, fontWeight = FontWeight.Bold, fontSize = 13.sp, fontFamily = FontFamily.Monospace))
                    }
                    Slider(
                        value = maxDailyLoss.toFloat(),
                        onValueChange = { viewModel.updateMaxDailyLoss(Math.round(it / 50.0) * 50.0) },
                        valueRange = 100f..2000f,
                        steps = 18,
                        colors = SliderDefaults.colors(thumbColor = RedBear, activeTrackColor = RedBear, inactiveTrackColor = SurfaceTerminal)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Max Concurrent Trades Slider
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(text = AppStrings.get("max_open_trades", language), style = TextStyle(color = TextSecondary, fontSize = 12.sp))
                        Text(text = "$maxOpenTrades Trades", style = TextStyle(color = BlueEma, fontWeight = FontWeight.Bold, fontSize = 13.sp, fontFamily = FontFamily.Monospace))
                    }
                    Slider(
                        value = maxOpenTrades.toFloat(),
                        onValueChange = { viewModel.botEngine.setMaxOpenTrades(it.toInt()) },
                        valueRange = 1f..10f,
                        steps = 8,
                        colors = SliderDefaults.colors(thumbColor = BlueEma, activeTrackColor = BlueEma, inactiveTrackColor = SurfaceTerminal)
                    )
                }
            }
        }

        // Demo Capital Reset Section
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = CardTerminal),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorderTerminal))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Refresh, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = AppStrings.get("reset_account", language),
                            style = TextStyle(color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(5000.0, 10000.0, 25000.0, 50000.0).forEach { amount ->
                            OutlinedButton(
                                onClick = {
                                    viewModel.resetAccount(amount)
                                    Toast.makeText(context, AppStrings.get("reset_success", language), Toast.LENGTH_SHORT).show()
                                },
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(36.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = GoldPrimary)
                            ) {
                                Text(
                                    text = "$${(amount / 1000).toInt()}k",
                                    style = TextStyle(fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Gold Trading & Bot Knowledge Base Card (Gujarati & English)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceTerminal),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorderTerminal))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (language == AppLanguage.GUJARATI) "સોનાના ટ્રેડિંગના મહત્વના નિયમો" else "Gold Trading Key Rules",
                            style = TextStyle(color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (language == AppLanguage.GUJARATI) {
                        Text(
                            text = "• 1 Standard Lot (1.00) = 100 ઔંસ સોનું. $1 નો ભાવ ફેરફાર = $100 નફો/નુકસાન.\n" +
                                    "• RSI < 30 માં બોટ બાય સિગ્નલ શોધે છે, અને RSI > 70 માં સેલ.\n" +
                                    "• ટ્રેલિંગ સ્ટોપ-લોસ 20 પિપ્સ નફો થતાં ઓટો-લોક થઈ જાય છે.\n" +
                                    "• US CPI, NFP અને FED મીટિંગ સમયે વોલેટિલિટી સૌથી વધુ હોય છે.",
                            style = TextStyle(color = TextSecondary, fontSize = 12.sp, lineHeight = 18.sp)
                        )
                    } else {
                        Text(
                            text = "• 1 Standard Lot (1.00) = 100 oz Gold. $1 price movement = $100 P&L.\n" +
                                    "• Scalper Bot buys when RSI < 30 at lower BB and sells when RSI > 70.\n" +
                                    "• Trailing Stop-Loss locks profit into breakeven (+15 pips) after +20 pips gain.\n" +
                                    "• Highest gold volatility occurs during US London-NY crossover & Fed rate news.",
                            style = TextStyle(color = TextSecondary, fontSize = 12.sp, lineHeight = 18.sp)
                        )
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(80.dp)) }
    }
}
