package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timeline
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppStrings
import com.example.data.model.Timeframe
import com.example.ui.components.CandlestickChart
import com.example.ui.components.LiveTickerBar
import com.example.ui.theme.BgTerminal
import com.example.ui.theme.BlueEma
import com.example.ui.theme.CardBorderTerminal
import com.example.ui.theme.CardTerminal
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GreenBull
import com.example.ui.theme.OrangeEma
import com.example.ui.theme.PurpleIndicator
import com.example.ui.theme.RedBear
import com.example.ui.theme.SurfaceTerminal
import com.example.ui.theme.TextGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.TradingViewModel
import java.util.Locale

@Composable
fun LiveChartScreen(
    viewModel: TradingViewModel,
    modifier: Modifier = Modifier
) {
    val language by viewModel.language.collectAsStateWithLifecycle()
    val tick by viewModel.currentTick.collectAsStateWithLifecycle()
    val candles by viewModel.activeCandles.collectAsStateWithLifecycle()
    val selectedTimeframe by viewModel.selectedTimeframe.collectAsStateWithLifecycle()
    val pivots by viewModel.pivotLevels.collectAsStateWithLifecycle()
    val simSpeed by viewModel.simulationSpeed.collectAsStateWithLifecycle()

    var showEma by remember { mutableStateOf(true) }
    var showBollinger by remember { mutableStateOf(true) }
    var showRsi by remember { mutableStateOf(true) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BgTerminal)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Spacer(modifier = Modifier.height(6.dp)) }

        // Live Ticker Header
        item {
            LiveTickerBar(tick = tick, language = language)
        }

        // Timeframe Selector & Sim Speed Controls
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Timeframes
                Row(
                    modifier = Modifier
                        .background(CardTerminal, RoundedCornerShape(12.dp))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Timeframe.values().forEach { tf ->
                        val isSelected = tf == selectedTimeframe
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) GoldPrimary else SurfaceTerminal)
                                .clickable { viewModel.setTimeframe(tf) }
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = tf.label,
                                style = TextStyle(
                                    color = if (isSelected) BgTerminal else TextSecondary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }
                }

                // Speed Selector (1x, 2x, 5x, 10x)
                Row(
                    modifier = Modifier
                        .background(CardTerminal, RoundedCornerShape(12.dp))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf(1, 2, 5, 10).forEach { speed ->
                        val isSelected = speed == simSpeed
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) BlueEma else SurfaceTerminal)
                                .clickable { viewModel.setSimulationSpeed(speed) }
                                .padding(horizontal = 6.dp, vertical = 6.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${speed}x",
                                style = TextStyle(
                                    color = if (isSelected) BgTerminal else TextSecondary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            )
                        }
                    }
                }
            }
        }

        // Indicator Toggle Filters
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = showEma,
                    onClick = { showEma = !showEma },
                    label = { Text("EMA (9, 21)", fontSize = 11.sp) },
                    leadingIcon = {
                        Box(modifier = Modifier.size(8.dp).background(BlueEma, CircleShape))
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CardTerminal,
                        selectedLabelColor = TextPrimary,
                        containerColor = SurfaceTerminal,
                        labelColor = TextMuted
                    )
                )

                FilterChip(
                    selected = showBollinger,
                    onClick = { showBollinger = !showBollinger },
                    label = { Text("Bollinger Bands", fontSize = 11.sp) },
                    leadingIcon = {
                        Box(modifier = Modifier.size(8.dp).background(OrangeEma, CircleShape))
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CardTerminal,
                        selectedLabelColor = TextPrimary,
                        containerColor = SurfaceTerminal,
                        labelColor = TextMuted
                    )
                )

                FilterChip(
                    selected = showRsi,
                    onClick = { showRsi = !showRsi },
                    label = { Text("RSI (14)", fontSize = 11.sp) },
                    leadingIcon = {
                        Box(modifier = Modifier.size(8.dp).background(PurpleIndicator, CircleShape))
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = CardTerminal,
                        selectedLabelColor = TextPrimary,
                        containerColor = SurfaceTerminal,
                        labelColor = TextMuted
                    )
                )
            }
        }

        // Canvas Candlestick Chart View
        item {
            CandlestickChart(
                candles = candles,
                currentPrice = tick.price,
                showEma = showEma,
                showBollinger = showBollinger,
                showRsiSubchart = showRsi,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(340.dp)
            )
        }

        // Daily Pivot Points Analysis Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardTerminal),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorderTerminal))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = AppStrings.get("pivot_levels", language),
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = GoldPrimary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    // Resistance Levels (R3, R2, R1)
                    PivotRow("R3 (Strong Resistance)", pivots.r3, RedBear, tick.price)
                    PivotRow("R2 (Take Profit Zone)", pivots.r2, RedBear.copy(alpha = 0.8f), tick.price)
                    PivotRow("R1 (Breakout Threshold)", pivots.r1, RedBear.copy(alpha = 0.6f), tick.price)

                    // Daily Pivot
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(SurfaceTerminal, RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Daily Central Pivot (P)",
                            style = TextStyle(color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        )
                        Text(
                            text = "$${String.format(Locale.US, "%.2f", pivots.pivot)}",
                            style = TextStyle(color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                        )
                    }

                    // Support Levels (S1, S2, S3)
                    PivotRow("S1 (Dip Buy Zone)", pivots.s1, GreenBull.copy(alpha = 0.6f), tick.price)
                    PivotRow("S2 (Support Accumulation)", pivots.s2, GreenBull.copy(alpha = 0.8f), tick.price)
                    PivotRow("S3 (Major Floor Support)", pivots.s3, GreenBull, tick.price)
                }
            }
        }

        item { Spacer(modifier = Modifier.height(80.dp)) }
    }
}

@Composable
private fun PivotRow(
    label: String,
    price: Double,
    color: androidx.compose.ui.graphics.Color,
    currentPrice: Double
) {
    val isNear = kotlin.math.abs(price - currentPrice) < 1.50
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp, horizontal = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .background(color, CircleShape)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = label,
                style = TextStyle(
                    color = if (isNear) TextPrimary else TextSecondary,
                    fontSize = 11.sp,
                    fontWeight = if (isNear) FontWeight.Bold else FontWeight.Normal
                )
            )
        }

        Text(
            text = "$${String.format(Locale.US, "%.2f", price)}",
            style = TextStyle(
                color = color,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold
            )
        )
    }
}
