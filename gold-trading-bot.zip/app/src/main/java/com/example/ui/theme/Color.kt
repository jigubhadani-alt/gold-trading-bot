package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Gold Trading Terminal Palette
val GoldPrimary = Color(0xFFFFB300)
val GoldSecondary = Color(0xFFFFD54F)
val GoldTertiary = Color(0xFFFFE082)
val GoldDark = Color(0xFFC67C00)

val GreenBull = Color(0xFF00E676)
val GreenBullBg = Color(0x1A00E676)
val RedBear = Color(0xFFFF3B69)
val RedBearBg = Color(0x1AFF3B69)

val BlueEma = Color(0xFF38BDF8)
val OrangeEma = Color(0xFFFB923C)
val PurpleIndicator = Color(0xFFA78BFA)
val CyanGrid = Color(0xFF22D3EE)

val BgTerminal = Color(0xFF0B0E14)
val SurfaceTerminal = Color(0xFF131B26)
val CardTerminal = Color(0xFF1A2433)
val CardBorderTerminal = Color(0xFF29384D)
val CardElevated = Color(0xFF223044)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val TextGold = Color(0xFFFFD54F)
