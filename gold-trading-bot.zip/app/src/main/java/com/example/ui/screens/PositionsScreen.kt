package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppStrings
import com.example.data.model.Trade
import com.example.data.model.TradeType
import com.example.ui.components.AccountHeaderCard
import com.example.ui.components.PositionCard
import com.example.ui.theme.BgTerminal
import com.example.ui.theme.CardBorderTerminal
import com.example.ui.theme.CardTerminal
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GoldSecondary
import com.example.ui.theme.GreenBull
import com.example.ui.theme.GreenBullBg
import com.example.ui.theme.RedBear
import com.example.ui.theme.RedBearBg
import com.example.ui.theme.SurfaceTerminal
import com.example.ui.theme.TextGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.TradingViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun PositionsScreen(
    viewModel: TradingViewModel,
    modifier: Modifier = Modifier
) {
    val language by viewModel.language.collectAsStateWithLifecycle()
    val account by viewModel.accountSummary.collectAsStateWithLifecycle()
    val openTrades by viewModel.openTrades.collectAsStateWithLifecycle()
    val closedTrades by viewModel.closedTrades.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Open Trades, 1: History

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BgTerminal)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Spacer(modifier = Modifier.height(6.dp)) }

        // Account Balance Overview
        item {
            AccountHeaderCard(account = account, language = language)
        }

        // Tabs: Open Positions vs Trade History
        item {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = CardTerminal,
                contentColor = GoldPrimary,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = GoldPrimary,
                        height = 3.dp
                    )
                },
                modifier = Modifier.clip(RoundedCornerShape(12.dp))
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Text(
                            text = "${AppStrings.get("open_positions", language)} (${openTrades.size})",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Text(
                            text = "${AppStrings.get("trade_history", language)} (${closedTrades.size})",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                )
            }
        }

        if (selectedTab == 0) {
            // Open Positions Tab
            if (openTrades.isNotEmpty()) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Live Active Trades",
                            style = TextStyle(color = TextSecondary, fontSize = 13.sp)
                        )

                        Button(
                            onClick = { viewModel.closeAllTrades() },
                            colors = ButtonDefaults.buttonColors(containerColor = RedBearBg, contentColor = RedBear),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Icon(Icons.Default.DoneAll, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = AppStrings.get("close_all", language), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                items(openTrades, key = { it.id }) { trade ->
                    PositionCard(
                        trade = trade,
                        language = language,
                        onClose = { viewModel.closeTrade(trade) }
                    )
                }
            } else {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = CardTerminal),
                        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorderTerminal))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "📈",
                                fontSize = 36.sp
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = AppStrings.get("no_open_positions", language),
                                style = TextStyle(color = TextMuted, fontSize = 13.sp),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }
            }
        } else {
            // Closed Trade History Tab
            if (closedTrades.isNotEmpty()) {
                // Performance Metrics Summary Strip
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = CardTerminal),
                        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorderTerminal))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(horizontalAlignment = Alignment.Start) {
                                Text("Total Profit", style = TextStyle(color = TextMuted, fontSize = 10.sp))
                                Text(
                                    "${if (account.totalRealizedProfit >= 0) "+" else ""}$${String.format(Locale.US, "%.2f", account.totalRealizedProfit)}",
                                    style = TextStyle(
                                        color = if (account.totalRealizedProfit >= 0) GreenBull else RedBear,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                )
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Profit Factor", style = TextStyle(color = TextMuted, fontSize = 10.sp))
                                Text(
                                    String.format(Locale.US, "%.2f", account.profitFactor),
                                    style = TextStyle(color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Best Trade", style = TextStyle(color = TextMuted, fontSize = 10.sp))
                                Text(
                                    "+$${String.format(Locale.US, "%.2f", account.bestTrade)}",
                                    style = TextStyle(color = GreenBull, fontWeight = FontWeight.Bold, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                                )
                            }
                        }
                    }
                }

                items(closedTrades, key = { it.id }) { trade ->
                    ClosedTradeCard(trade = trade)
                }
            } else {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = CardTerminal),
                        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorderTerminal))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.History,
                                contentDescription = null,
                                tint = TextMuted,
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = AppStrings.get("no_history", language),
                                style = TextStyle(color = TextMuted, fontSize = 13.sp),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(80.dp)) }
    }
}

@Composable
private fun ClosedTradeCard(
    trade: Trade,
    modifier: Modifier = Modifier
) {
    val isBuy = trade.type == TradeType.BUY
    val typeColor = if (isBuy) GreenBull else RedBear
    val pnlPositive = trade.pnl >= 0
    val pnlColor = if (pnlPositive) GreenBull else RedBear
    val timeStr = trade.closeTime?.let { SimpleDateFormat("MM/dd HH:mm", Locale.getDefault()).format(Date(it)) } ?: ""

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CardTerminal),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorderTerminal))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .background(typeColor.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = trade.type.name,
                            style = TextStyle(color = typeColor, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${trade.symbol} • ${trade.lotSize} Lot",
                        style = TextStyle(color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    )
                }

                Text(
                    text = "${if (pnlPositive) "+" else ""}$${String.format(Locale.US, "%.2f", trade.pnl)}",
                    style = TextStyle(
                        color = pnlColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        fontFamily = FontFamily.Monospace
                    )
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "$${String.format(Locale.US, "%.2f", trade.entryPrice)} → $${String.format(Locale.US, "%.2f", trade.exitPrice ?: trade.currentPrice)}",
                    style = TextStyle(color = TextMuted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                )

                Text(
                    text = trade.closeReason ?: "",
                    style = TextStyle(color = TextSecondary, fontSize = 11.sp)
                )
            }
        }
    }
}
