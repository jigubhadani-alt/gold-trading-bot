package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val GoldBotColorScheme = darkColorScheme(
    primary = GoldPrimary,
    onPrimary = BgTerminal,
    primaryContainer = CardElevated,
    onPrimaryContainer = GoldTertiary,
    secondary = GoldSecondary,
    onSecondary = BgTerminal,
    secondaryContainer = CardTerminal,
    onSecondaryContainer = TextPrimary,
    tertiary = BlueEma,
    onTertiary = BgTerminal,
    background = BgTerminal,
    onBackground = TextPrimary,
    surface = SurfaceTerminal,
    onSurface = TextPrimary,
    surfaceVariant = CardTerminal,
    onSurfaceVariant = TextSecondary,
    outline = CardBorderTerminal,
    outlineVariant = CardTerminal
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Use custom gold palette for consistent trading UI
    content: @Composable () -> Unit
) {
    val colorScheme = GoldBotColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = BgTerminal.toArgb()
            window.navigationBarColor = BgTerminal.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = false
            WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = false
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
