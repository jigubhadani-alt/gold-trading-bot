package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AccountSummary
import com.example.data.model.AppLanguage
import com.example.data.model.AppStrings
import com.example.data.model.BotLog
import com.example.data.model.BotStrategyConfig
import com.example.data.model.LogLevel
import com.example.data.model.MarketTick
import com.example.data.model.StrategyType
import com.example.data.model.Trade
import com.example.data.model.TradeType
import com.example.ui.theme.BgTerminal
import com.example.ui.theme.BlueEma
import com.example.ui.theme.CardBorderTerminal
import com.example.ui.theme.CardElevated
import com.example.ui.theme.CardTerminal
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GoldSecondary
import com.example.ui.theme.GoldTertiary
import com.example.ui.theme.GreenBull
import com.example.ui.theme.GreenBullBg
import com.example.ui.theme.OrangeEma
import com.example.ui.theme.PurpleIndicator
import com.example.ui.theme.RedBear
import com.example.ui.theme.RedBearBg
import com.example.ui.theme.SurfaceTerminal
import com.example.ui.theme.TextGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

@Composable
fun AccountHeaderCard(
    account: AccountSummary,
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = CardTerminal),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorderTerminal))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(GoldPrimary.copy(alpha = 0.2f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AccountBalanceWallet,
                            contentDescription = null,
                            tint = GoldPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = AppStrings.get("account_balance", language),
                            style = TextStyle(color = TextSecondary, fontSize = 12.sp)
                        )
                        Text(
                            text = "$${String.format(Locale.US, "%,.2f", account.balance)}",
                            style = TextStyle(
                                color = TextPrimary,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        )
                    }
                }

                // Floating P&L Pill
                val pnlPositive = account.floatingPnl >= 0
                val pnlColor = if (pnlPositive) GreenBull else RedBear
                val pnlBg = if (pnlPositive) GreenBullBg else RedBearBg

                Box(
                    modifier = Modifier
                        .background(pnlBg, RoundedCornerShape(12.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = AppStrings.get("account_pnl", language),
                            style = TextStyle(color = TextMuted, fontSize = 10.sp)
                        )
                        Text(
                            text = "${if (pnlPositive) "+" else ""}$${String.format(Locale.US, "%.2f", account.floatingPnl)}",
                            style = TextStyle(
                                color = pnlColor,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Sub Stats Grid (Equity, Free Margin, Win Rate)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceTerminal, RoundedCornerShape(12.dp))
                    .padding(vertical = 10.dp, horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(horizontalAlignment = Alignment.Start) {
                    Text(text = AppStrings.get("account_equity", language), style = TextStyle(color = TextMuted, fontSize = 11.sp))
                    Text(
                        text = "$${String.format(Locale.US, "%,.2f", account.equity)}",
                        style = TextStyle(color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                    )
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(text = AppStrings.get("margin_free", language), style = TextStyle(color = TextMuted, fontSize = 11.sp))
                    Text(
                        text = "$${String.format(Locale.US, "%,.2f", account.freeMargin)}",
                        style = TextStyle(color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(text = AppStrings.get("win_rate", language), style = TextStyle(color = TextMuted, fontSize = 11.sp))
                    Text(
                        text = "${String.format(Locale.US, "%.1f", account.winRate)}%",
                        style = TextStyle(color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                    )
                }
            }
        }
    }
}

@Composable
fun LiveTickerBar(
    tick: MarketTick,
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    val isPositive = tick.change24h >= 0
    val changeColor = if (isPositive) GreenBull else RedBear

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CardTerminal),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorderTerminal))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "XAU/USD",
                        style = TextStyle(color = GoldPrimary, fontWeight = FontWeight.Black, fontSize = 16.sp, letterSpacing = 0.5.sp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .background(CardBorderTerminal, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "GOLD SPOT",
                            style = TextStyle(color = TextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "$${String.format(Locale.US, "%.2f", tick.price)}",
                    style = TextStyle(
                        color = TextPrimary,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isPositive) Icons.Default.ArrowUpward else Icons.Default.ArrowDownward,
                        contentDescription = null,
                        tint = changeColor,
                        modifier = Modifier.size(14.dp)
                    )
                    Text(
                        text = "${if (isPositive) "+" else ""}${String.format(Locale.US, "%.2f", tick.change24h)} (${String.format(Locale.US, "%.2f", tick.changePercent24h)}%)",
                        style = TextStyle(
                            color = changeColor,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Spread: $${String.format(Locale.US, "%.2f", tick.spread)}",
                    style = TextStyle(color = TextMuted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                )
            }
        }
    }
}

@Composable
fun StrategyCard(
    strategy: BotStrategyConfig,
    language: AppLanguage,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier
) {
    val title = if (language == AppLanguage.GUJARATI) strategy.type.titleGu else strategy.type.titleEn
    val desc = when (strategy.type) {
        StrategyType.SCALPER -> AppStrings.get("strat_scalper_desc", language)
        StrategyType.TREND_FOLLOWING -> AppStrings.get("strat_trend_desc", language)
        StrategyType.GRID_BOT -> AppStrings.get("strat_grid_desc", language)
        StrategyType.BREAKOUT -> AppStrings.get("strat_breakout_desc", language)
        StrategyType.MANUAL -> ""
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onToggle() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (strategy.isEnabled) CardTerminal else SurfaceTerminal
        ),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(
                if (strategy.isEnabled) GoldPrimary.copy(alpha = 0.6f) else CardBorderTerminal
            )
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = if (strategy.isEnabled) GoldPrimary else TextSecondary,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = desc,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    )
                }

                Switch(
                    checked = strategy.isEnabled,
                    onCheckedChange = { onToggle() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = BgTerminal,
                        checkedTrackColor = GoldPrimary,
                        uncheckedThumbColor = TextMuted,
                        uncheckedTrackColor = SurfaceTerminal
                    )
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Strategy Stats Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceTerminal.copy(alpha = 0.7f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Lot: ${strategy.defaultLotSize} | SL: ${strategy.stopLossPips.toInt()}p | TP: ${strategy.takeProfitPips.toInt()}p",
                    style = TextStyle(color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                )
                Text(
                    text = "Win: ${String.format(Locale.US, "%.0f", strategy.winRate)}% (+$${String.format(Locale.US, "%.0f", strategy.totalProfit)})",
                    style = TextStyle(color = GreenBull, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                )
            }
        }
    }
}

@Composable
fun PositionCard(
    trade: Trade,
    language: AppLanguage,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isBuy = trade.type == TradeType.BUY
    val typeColor = if (isBuy) GreenBull else RedBear
    val pnlPositive = trade.pnl >= 0
    val pnlColor = if (pnlPositive) GreenBull else RedBear

    Card(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CardTerminal),
        border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorderTerminal))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .background(typeColor.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = trade.type.name,
                            style = TextStyle(color = typeColor, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "${trade.symbol} • ${trade.lotSize} Lots",
                        style = TextStyle(color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    )
                }

                Text(
                    text = "#${trade.ticketNumber}",
                    style = TextStyle(color = TextMuted, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Entry / Current Price & PnL
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Entry: $${String.format(Locale.US, "%.2f", trade.entryPrice)} → Now: $${String.format(Locale.US, "%.2f", trade.currentPrice)}",
                        style = TextStyle(color = TextSecondary, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "SL: $${String.format(Locale.US, "%.2f", trade.stopLoss)} | TP: $${String.format(Locale.US, "%.2f", trade.takeProfit)}",
                        style = TextStyle(color = TextMuted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "${if (pnlPositive) "+" else ""}$${String.format(Locale.US, "%.2f", trade.pnl)}",
                        style = TextStyle(
                            color = pnlColor,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    )
                    Text(
                        text = "${if (trade.pips >= 0) "+" else ""}${String.format(Locale.US, "%.1f", trade.pips)} pips",
                        style = TextStyle(color = pnlColor, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Footer / Close Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Strat: ${trade.strategy.name}",
                    style = TextStyle(color = GoldTertiary, fontSize = 11.sp)
                )

                OutlinedButton(
                    onClick = onClose,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = RedBear),
                    border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(RedBear.copy(alpha = 0.5f))),
                    modifier = Modifier.height(32.dp)
                ) {
                    Text(text = AppStrings.get("close_trade", language), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun BotLogItemCard(
    log: BotLog,
    modifier: Modifier = Modifier
) {
    val color = when (log.level) {
        LogLevel.SUCCESS -> GreenBull
        LogLevel.TRADE -> GoldPrimary
        LogLevel.SIGNAL -> BlueEma
        LogLevel.WARNING -> RedBear
        LogLevel.INFO -> TextSecondary
    }

    val timeStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(log.timestamp))

    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = "[$timeStr]",
            style = TextStyle(color = TextMuted, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = log.message,
            style = TextStyle(color = color, fontSize = 12.sp, fontFamily = FontFamily.Monospace),
            modifier = Modifier.weight(1f)
        )
    }
}
