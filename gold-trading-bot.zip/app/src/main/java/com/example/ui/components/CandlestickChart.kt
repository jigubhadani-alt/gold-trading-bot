package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CandleStick
import com.example.ui.theme.BgTerminal
import com.example.ui.theme.BlueEma
import com.example.ui.theme.CardBorderTerminal
import com.example.ui.theme.CardTerminal
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GreenBull
import com.example.ui.theme.OrangeEma
import com.example.ui.theme.PurpleIndicator
import com.example.ui.theme.RedBear
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

@Composable
fun CandlestickChart(
    candles: List<CandleStick>,
    currentPrice: Double,
    modifier: Modifier = Modifier,
    showEma: Boolean = true,
    showBollinger: Boolean = true,
    showRsiSubchart: Boolean = true
) {
    val textMeasurer = rememberTextMeasurer()
    var selectedCandleIndex by remember { mutableStateOf<Int?>(null) }

    val activeCandles = remember(candles) {
        if (candles.size > 40) candles.takeLast(40) else candles
    }

    val selectedCandle = selectedCandleIndex?.let { idx ->
        if (idx in activeCandles.indices) activeCandles[idx] else null
    } ?: activeCandles.lastOrNull()

    Column(
        modifier = modifier
            .background(CardTerminal, RoundedCornerShape(16.dp))
            .padding(12.dp)
    ) {
        // Top Candle Inspection Header (OHLCV)
        selectedCandle?.let { c ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "O: ${String.format(Locale.US, "%.2f", c.open)}",
                        style = TextStyle(fontSize = 11.sp, color = TextSecondary, fontFamily = FontFamily.Monospace)
                    )
                    Text(
                        text = "H: ${String.format(Locale.US, "%.2f", c.high)}",
                        style = TextStyle(fontSize = 11.sp, color = GreenBull, fontFamily = FontFamily.Monospace)
                    )
                    Text(
                        text = "L: ${String.format(Locale.US, "%.2f", c.low)}",
                        style = TextStyle(fontSize = 11.sp, color = RedBear, fontFamily = FontFamily.Monospace)
                    )
                    Text(
                        text = "C: ${String.format(Locale.US, "%.2f", c.close)}",
                        style = TextStyle(
                            fontSize = 11.sp,
                            color = if (c.close >= c.open) GreenBull else RedBear,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    )
                }

                c.rsi14?.let { rsi ->
                    Text(
                        text = "RSI: ${String.format(Locale.US, "%.1f", rsi)}",
                        style = TextStyle(
                            fontSize = 11.sp,
                            color = when {
                                rsi < 30 -> GreenBull
                                rsi > 70 -> RedBear
                                else -> PurpleIndicator
                            },
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    )
                }
            }
        }

        // Main Candlestick Chart Canvas
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(activeCandles) {
                        detectTapGestures { offset ->
                            val candleWidth = size.width / activeCandles.size
                            val index = (offset.x / candleWidth).toInt().coerceIn(0, activeCandles.size - 1)
                            selectedCandleIndex = index
                        }
                    }
            ) {
                if (activeCandles.isEmpty()) return@Canvas

                val mainHeight = if (showRsiSubchart) size.height * 0.72f else size.height
                val rsiTop = mainHeight + 16f
                val rsiHeight = size.height - rsiTop

                // Calculate Min/Max Price Bounds with 5% padding
                val allHighs = activeCandles.map { it.high } + (if (showBollinger) activeCandles.mapNotNull { it.upperBand } else emptyList())
                val allLows = activeCandles.map { it.low } + (if (showBollinger) activeCandles.mapNotNull { it.lowerBand } else emptyList())
                val minPrice = (allLows.minOrNull() ?: currentPrice) * 0.9995
                val maxPrice = (allHighs.maxOrNull() ?: currentPrice) * 1.0005
                val priceRange = max(0.1, maxPrice - minPrice)

                val n = activeCandles.size
                val stepX = size.width / n
                val candleBodyWidth = max(2f, stepX * 0.65f)

                // 1. Draw Horizontal Grid Lines & Price Labels
                val gridLines = 5
                for (i in 0..gridLines) {
                    val y = mainHeight * (i.toFloat() / gridLines)
                    val priceAtY = maxPrice - (i.toDouble() / gridLines) * priceRange
                    drawLine(
                        color = CardBorderTerminal.copy(alpha = 0.5f),
                        start = Offset(0f, y),
                        end = Offset(size.width, y),
                        strokeWidth = 1f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
                    )
                    drawText(
                        textMeasurer = textMeasurer,
                        text = String.format(Locale.US, "%.1f", priceAtY),
                        topLeft = Offset(size.width - 55f, y - 16f),
                        style = TextStyle(color = TextMuted, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    )
                }

                // 2. Draw Bollinger Bands Area
                if (showBollinger) {
                    val upperPath = Path()
                    val lowerPath = Path()
                    var first = true

                    activeCandles.forEachIndexed { i, c ->
                        val x = (i + 0.5f) * stepX
                        val upper = c.upperBand ?: c.high
                        val lower = c.lowerBand ?: c.low
                        val yUpper = (mainHeight * (1f - ((upper - minPrice) / priceRange))).toFloat()
                        val yLower = (mainHeight * (1f - ((lower - minPrice) / priceRange))).toFloat()

                        if (first) {
                            upperPath.moveTo(x, yUpper)
                            lowerPath.moveTo(x, yLower)
                            first = false
                        } else {
                            upperPath.lineTo(x, yUpper)
                            lowerPath.lineTo(x, yLower)
                        }
                    }

                    drawPath(
                        path = upperPath,
                        color = Color(0x5538BDF8),
                        style = Stroke(width = 1.2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f), 0f))
                    )
                    drawPath(
                        path = lowerPath,
                        color = Color(0x5538BDF8),
                        style = Stroke(width = 1.2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f), 0f))
                    )
                }

                // 3. Draw EMA Lines
                if (showEma) {
                    drawIndicatorLine(activeCandles, { it.ema9 }, minPrice, priceRange, mainHeight, stepX, BlueEma)
                    drawIndicatorLine(activeCandles, { it.ema21 }, minPrice, priceRange, mainHeight, stepX, OrangeEma)
                }

                // 4. Draw Candlesticks (Wicks and Bodies)
                activeCandles.forEachIndexed { i, c ->
                    val centerX = (i + 0.5f) * stepX
                    val isBullish = c.close >= c.open
                    val candleColor = if (isBullish) GreenBull else RedBear

                    val yHigh = (mainHeight * (1f - ((c.high - minPrice) / priceRange))).toFloat()
                    val yLow = (mainHeight * (1f - ((c.low - minPrice) / priceRange))).toFloat()
                    val yOpen = (mainHeight * (1f - ((c.open - minPrice) / priceRange))).toFloat()
                    val yClose = (mainHeight * (1f - ((c.close - minPrice) / priceRange))).toFloat()

                    // Wick
                    drawLine(
                        color = candleColor,
                        start = Offset(centerX, yHigh),
                        end = Offset(centerX, yLow),
                        strokeWidth = 1.5f
                    )

                    // Body
                    val bodyTop = min(yOpen, yClose)
                    val bodyHeight = max(2f, kotlin.math.abs(yClose - yOpen))

                    drawRect(
                        color = candleColor,
                        topLeft = Offset(centerX - (candleBodyWidth / 2f), bodyTop),
                        size = Size(candleBodyWidth, bodyHeight),
                        style = Fill
                    )
                }

                // 5. Draw Current Price Tag & Dashed Line
                val currentY = (mainHeight * (1f - ((currentPrice - minPrice) / priceRange))).toFloat().coerceIn(0f, mainHeight)
                drawLine(
                    color = GoldPrimary,
                    start = Offset(0f, currentY),
                    end = Offset(size.width, currentY),
                    strokeWidth = 1.8f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 6f), 0f)
                )

                // Price badge on right edge
                drawRect(
                    color = GoldPrimary,
                    topLeft = Offset(size.width - 64f, currentY - 10f),
                    size = Size(64f, 20f),
                    style = Fill
                )
                drawText(
                    textMeasurer = textMeasurer,
                    text = String.format(Locale.US, "%.2f", currentPrice),
                    topLeft = Offset(size.width - 60f, currentY - 8f),
                    style = TextStyle(color = BgTerminal, fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                )

                // 6. RSI Subchart (if enabled)
                if (showRsiSubchart && rsiHeight > 10f) {
                    // Divider
                    drawLine(
                        color = CardBorderTerminal,
                        start = Offset(0f, mainHeight + 6f),
                        end = Offset(size.width, mainHeight + 6f),
                        strokeWidth = 1.5f
                    )

                    // RSI 70 & 30 Lines
                    val y70 = rsiTop + (rsiHeight * (1f - 0.70f))
                    val y30 = rsiTop + (rsiHeight * (1f - 0.30f))

                    drawLine(
                        color = RedBear.copy(alpha = 0.5f),
                        start = Offset(0f, y70),
                        end = Offset(size.width, y70),
                        strokeWidth = 1f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f), 0f)
                    )
                    drawLine(
                        color = GreenBull.copy(alpha = 0.5f),
                        start = Offset(0f, y30),
                        end = Offset(size.width, y30),
                        strokeWidth = 1f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 4f), 0f)
                    )

                    // RSI Curve
                    val rsiPath = Path()
                    var rsiFirst = true
                    activeCandles.forEachIndexed { i, c ->
                        val rsiVal = c.rsi14 ?: 50.0
                        val x = (i + 0.5f) * stepX
                        val y = (rsiTop + (rsiHeight * (1f - (rsiVal.toFloat() / 100f)))).coerceIn(rsiTop, size.height)
                        if (rsiFirst) {
                            rsiPath.moveTo(x, y)
                            rsiFirst = false
                        } else {
                            rsiPath.lineTo(x, y)
                        }
                    }

                    drawPath(
                        path = rsiPath,
                        color = PurpleIndicator,
                        style = Stroke(width = 2f)
                    )

                    drawText(
                        textMeasurer = textMeasurer,
                        text = "RSI (14)",
                        topLeft = Offset(8f, rsiTop - 12f),
                        style = TextStyle(color = PurpleIndicator, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                    )
                }
            }
        }
    }
}

private fun DrawScope.drawIndicatorLine(
    candles: List<CandleStick>,
    selector: (CandleStick) -> Double?,
    minPrice: Double,
    priceRange: Double,
    mainHeight: Float,
    stepX: Float,
    color: Color
) {
    val path = Path()
    var first = true
    candles.forEachIndexed { i, c ->
        val value = selector(c)
        if (value != null) {
            val x = (i + 0.5f) * stepX
            val y = (mainHeight * (1f - ((value - minPrice) / priceRange))).toFloat()
            if (first) {
                path.moveTo(x, y)
                first = false
            } else {
                path.lineTo(x, y)
            }
        }
    }
    drawPath(path = path, color = color, style = Stroke(width = 1.6f))
}
