package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.AppStrings
import com.example.data.model.StrategyType
import com.example.data.model.TradeType
import com.example.ui.components.AccountHeaderCard
import com.example.ui.components.BotLogItemCard
import com.example.ui.components.LiveTickerBar
import com.example.ui.components.SignalGauge
import com.example.ui.components.StrategyCard
import com.example.ui.theme.BgTerminal
import com.example.ui.theme.CardBorderTerminal
import com.example.ui.theme.CardTerminal
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GoldSecondary
import com.example.ui.theme.GreenBull
import com.example.ui.theme.GreenBullBg
import com.example.ui.theme.RedBear
import com.example.ui.theme.RedBearBg
import com.example.ui.theme.SurfaceTerminal
import com.example.ui.theme.TextGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.TradingViewModel
import java.util.Locale

@Composable
fun BotDashboardScreen(
    viewModel: TradingViewModel,
    modifier: Modifier = Modifier
) {
    val language by viewModel.language.collectAsStateWithLifecycle()
    val tick by viewModel.currentTick.collectAsStateWithLifecycle()
    val signal by viewModel.latestSignal.collectAsStateWithLifecycle()
    val account by viewModel.accountSummary.collectAsStateWithLifecycle()
    val isBotActive by viewModel.isBotActive.collectAsStateWithLifecycle()
    val strategies by viewModel.strategies.collectAsStateWithLifecycle()
    val recentLogs by viewModel.recentLogs.collectAsStateWithLifecycle()
    val simSpeed by viewModel.simulationSpeed.collectAsStateWithLifecycle()

    var manualLotSize by remember { mutableDoubleStateOf(0.50) }
    var manualSlPips by remember { mutableDoubleStateOf(25.0) }
    var manualTpPips by remember { mutableDoubleStateOf(50.0) }

    // Pulsing animation for active bot indicator
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900),
            repeatMode = RepeatMode.Reverse
        ),
        label = "botPulse"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(BgTerminal)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Spacer(modifier = Modifier.height(6.dp)) }

        // Master Bot Status & Control Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isBotActive) CardTerminal else SurfaceTerminal
                ),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = androidx.compose.ui.graphics.SolidColor(
                        if (isBotActive) GoldPrimary else CardBorderTerminal
                    )
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        // Pulsing Robot / Indicator Icon
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .background(
                                    if (isBotActive) GoldPrimary.copy(alpha = 0.2f) else CardBorderTerminal,
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.SmartToy,
                                contentDescription = null,
                                tint = if (isBotActive) GoldPrimary else TextMuted,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (isBotActive) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .alpha(pulseAlpha)
                                            .background(GreenBull, CircleShape)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                }
                                Text(
                                    text = if (isBotActive) {
                                        AppStrings.get("bot_status_active", language)
                                    } else {
                                        AppStrings.get("bot_status_paused", language)
                                    },
                                    style = TextStyle(
                                        color = if (isBotActive) GreenBull else TextSecondary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        letterSpacing = 0.5.sp
                                    )
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "${strategies.count { it.isEnabled }} Strategies Running",
                                style = TextStyle(color = TextMuted, fontSize = 11.sp)
                            )
                        }
                    }

                    // Main Bot Toggle Button
                    Button(
                        onClick = { viewModel.toggleBot() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isBotActive) RedBearBg else GoldPrimary,
                            contentColor = if (isBotActive) RedBear else BgTerminal
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.height(40.dp)
                    ) {
                        Icon(
                            imageVector = if (isBotActive) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isBotActive) {
                                AppStrings.get("bot_toggle_stop", language)
                            } else {
                                AppStrings.get("bot_toggle_start", language)
                            },
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Account Balance Header
        item {
            AccountHeaderCard(account = account, language = language)
        }

        // Real-time Gold Ticker
        item {
            LiveTickerBar(tick = tick, language = language)
        }

        // AI Signal Radar & Technical Gauge
        item {
            SignalGauge(signal = signal, language = language)
        }

        // Quick Manual Order Panel
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CardTerminal),
                border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorderTerminal))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = AppStrings.get("quick_order", language),
                            style = MaterialTheme.typography.titleMedium.copy(
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        )

                        // Lot Size Stepper
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .background(SurfaceTerminal, RoundedCornerShape(8.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            IconButton(
                                onClick = { if (manualLotSize > 0.10) manualLotSize = Math.round((manualLotSize - 0.10) * 100.0) / 100.0 },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.Remove, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(16.dp))
                            }
                            Text(
                                text = "${String.format(Locale.US, "%.2f", manualLotSize)} Lot",
                                style = TextStyle(color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp, fontFamily = FontFamily.Monospace),
                                modifier = Modifier.padding(horizontal = 4.dp)
                            )
                            IconButton(
                                onClick = { if (manualLotSize < 5.0) manualLotSize = Math.round((manualLotSize + 0.10) * 100.0) / 100.0 },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(16.dp))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Instant Buy and Sell Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                viewModel.openManualTrade(TradeType.BUY, manualLotSize, manualSlPips, manualTpPips)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GreenBull, contentColor = BgTerminal),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                        ) {
                            Icon(Icons.Default.TrendingUp, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = AppStrings.get("btn_buy", language), fontWeight = FontWeight.Black, fontSize = 12.sp)
                                Text(text = "$${String.format(Locale.US, "%.2f", tick.ask)}", fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            }
                        }

                        Button(
                            onClick = {
                                viewModel.openManualTrade(TradeType.SELL, manualLotSize, manualSlPips, manualTpPips)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = RedBear, contentColor = TextPrimary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                        ) {
                            Icon(Icons.Default.TrendingDown, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = AppStrings.get("btn_sell", language), fontWeight = FontWeight.Black, fontSize = 12.sp)
                                Text(text = "$${String.format(Locale.US, "%.2f", tick.bid)}", fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }
        }

        // Trading Bot Strategies Section
        item {
            Text(
                text = AppStrings.get("strategies_title", language),
                style = MaterialTheme.typography.titleMedium.copy(
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                ),
                modifier = Modifier.padding(top = 4.dp)
            )
        }

        items(strategies) { strat ->
            StrategyCard(
                strategy = strat,
                language = language,
                onToggle = { viewModel.toggleStrategy(strat.type) }
            )
        }

        // Live Bot Activity Logs Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = AppStrings.get("bot_logs", language),
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )

                IconButton(onClick = { viewModel.clearLogs() }) {
                    Icon(
                        imageVector = Icons.Default.DeleteSweep,
                        contentDescription = AppStrings.get("clear_logs", language),
                        tint = TextMuted
                    )
                }
            }
        }

        if (recentLogs.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SurfaceTerminal, RoundedCornerShape(12.dp))
                        .padding(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Listening for bot trading signals...",
                        style = TextStyle(color = TextMuted, fontSize = 12.sp)
                    )
                }
            }
        } else {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = CardTerminal),
                    border = CardDefaults.outlinedCardBorder().copy(brush = androidx.compose.ui.graphics.SolidColor(CardBorderTerminal))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        recentLogs.take(6).forEach { log ->
                            BotLogItemCard(log = log)
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(80.dp)) }
    }
}
