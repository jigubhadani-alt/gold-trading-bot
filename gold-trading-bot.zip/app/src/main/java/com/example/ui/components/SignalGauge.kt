package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.TrendingDown
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.AppStrings
import com.example.data.model.SignalDecision
import com.example.data.model.SignalType
import com.example.ui.theme.BgTerminal
import com.example.ui.theme.CardBorderTerminal
import com.example.ui.theme.CardTerminal
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.GreenBull
import com.example.ui.theme.RedBear
import com.example.ui.theme.TextGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SignalGauge(
    signal: SignalDecision,
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    val animatedScore by animateFloatAsState(
        targetValue = signal.score.toFloat(),
        animationSpec = tween(durationMillis = 600),
        label = "gaugeNeedle"
    )

    val signalColor = when (signal.type) {
        SignalType.STRONG_BUY -> GreenBull
        SignalType.BUY -> Color(0xFF4ADE80)
        SignalType.NEUTRAL -> GoldPrimary
        SignalType.SELL -> Color(0xFFF87171)
        SignalType.STRONG_SELL -> RedBear
    }

    val signalKey = when (signal.type) {
        SignalType.STRONG_BUY -> "signal_strong_buy"
        SignalType.BUY -> "signal_buy"
        SignalType.NEUTRAL -> "signal_neutral"
        SignalType.SELL -> "signal_sell"
        SignalType.STRONG_SELL -> "signal_strong_sell"
    }

    Column(
        modifier = modifier
            .background(CardTerminal, RoundedCornerShape(16.dp))
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = GoldPrimary,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = AppStrings.get("ai_signal", language),
                    style = MaterialTheme.typography.titleMedium.copy(
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                )
            }

            // Confidence Tag
            Box(
                modifier = Modifier
                    .background(signalColor.copy(alpha = 0.15f), RoundedCornerShape(20.dp))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "${signal.confidence}% ${AppStrings.get("signal_confidence", language)}",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = signalColor,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Radial Speedometer Gauge Canvas
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(110.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(200.dp, 100.dp)) {
                val strokeWidth = 14f
                val radius = (size.width - strokeWidth) / 2f
                val arcTopLeft = Offset(strokeWidth / 2f, strokeWidth / 2f)
                val arcSize = Size(radius * 2f, radius * 2f)

                // Background Arc Segments: Red -> Orange -> Yellow -> Green
                // Start angle is 180 (left), sweep is 180 (semi-circle)
                drawArc(
                    brush = Brush.horizontalGradient(
                        listOf(RedBear, Color(0xFFFB923C), GoldPrimary, Color(0xFF4ADE80), GreenBull)
                    ),
                    startAngle = 180f,
                    sweepAngle = 180f,
                    useCenter = false,
                    topLeft = arcTopLeft,
                    size = arcSize,
                    style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                )

                // Needle: Score is -100 (180 deg) to +100 (360 / 0 deg)
                // Linear map: angle = 180 + ((score + 100) / 200) * 180
                val angleDeg = 180f + ((animatedScore + 100f) / 200f) * 180f
                val angleRad = Math.toRadians(angleDeg.toDouble())

                val needleLength = radius * 0.75f
                val centerOffset = Offset(size.width / 2f, size.height)
                val needleEnd = Offset(
                    x = centerOffset.x + (needleLength * cos(angleRad)).toFloat(),
                    y = centerOffset.y + (needleLength * sin(angleRad)).toFloat()
                )

                // Needle line
                drawLine(
                    color = TextPrimary,
                    start = centerOffset,
                    end = needleEnd,
                    strokeWidth = 4f,
                    cap = StrokeCap.Round
                )

                // Center pivot circle
                drawCircle(
                    color = GoldPrimary,
                    radius = 8f,
                    center = centerOffset
                )
            }

            // Signal Badge
            Column(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 0.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = AppStrings.get(signalKey, language),
                    style = MaterialTheme.typography.titleLarge.copy(
                        color = signalColor,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Signal Rationale
        Text(
            text = signal.reason,
            style = MaterialTheme.typography.bodySmall.copy(
                color = TextSecondary,
                fontSize = 12.sp
            ),
            modifier = Modifier.padding(horizontal = 8.dp)
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Suggested SL & TP Targets
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CardBorderTerminal.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.TrendingDown,
                    contentDescription = null,
                    tint = RedBear,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "SL: $${String.format(Locale.US, "%.2f", signal.suggestedSl)}",
                    style = TextStyle(color = RedBear, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.TrendingUp,
                    contentDescription = null,
                    tint = GreenBull,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "TP: $${String.format(Locale.US, "%.2f", signal.suggestedTp)}",
                    style = TextStyle(color = GreenBull, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                )
            }
        }
    }
}
